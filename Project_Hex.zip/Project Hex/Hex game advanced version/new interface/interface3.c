#include <gtk/gtk.h>
#include <stdbool.h>
#define PATH_EMPTY_CELL "./imgs/grey.png"
#define PATH_P1_CELL "./imgs/blue.png"
#define PATH_P2_CELL "./imgs/red.png"
#define SIZE_TAB_GUI 7 // 7 car faut ajouter les labels
#define SIZE 6

// pour effectuer changement sur grille, suffit de clicker sur le bouton en utilisant le code suivant
// g_signal_emit_by_name(button, "clicked");
// faire attention quand incrementer le tour, avant ou apres le click
int tour = 1;
GObject* game_grid;
GtkLabel* game_info_label;

int map_2d_to_1d(int row, int col)
{                
    // definit l'ordre du tableau 1 dim; indexes should be 1-6
    return ((row-1)*6) + col-1; // -1 sur row et col car ils debutent par 1 (0 contient les labels)
}

static void print_hello(GtkWidget *widget, gpointer data)
{
    g_print("Hello World\n");
}

static void quit_application (GtkWidget *widget, gpointer data)
{
GtkWindow *window = GTK_WINDOW(data);
gtk_window_close(window);
}

static void open_window(GtkWidget *widget, gpointer data)
{
GtkWindow *window =GTK_WINDOW(data) ;
gtk_widget_show(window);
}

static void set_cell_color(GtkWidget *widget, gpointer p_tour) // p_tour est l'addresse de la variable gloable tour
{
    // utilise le nbre de tour atteint pour savoir qui a joué j1 ou j2
    int tour = *(int*)p_tour; 
    int a_qui_le_tour = (tour%2)+1 ;// 1 pour j1, 2 pour j2
    g_print("joueur %d a joué\n",a_qui_le_tour);
    switch(a_qui_le_tour){
        case 2: // case remplie joueur 1
            gtk_button_set_child(GTK_BUTTON(widget), gtk_image_new_from_file(PATH_P1_CELL));
            break;
        case 1: // case remplie joueur 2
            gtk_button_set_child(GTK_BUTTON(widget), gtk_image_new_from_file(PATH_P2_CELL));
            break;
        default: // case vide
            gtk_button_set_child(GTK_BUTTON(widget), gtk_image_new_from_file(PATH_EMPTY_CELL));
            break;
    }
}

static void activate(GtkApplication *app, gpointer user_data)
{
    //initialisation variables
    
    GtkBuilder* builder_object = gtk_builder_new();
    GtkEntryBuffer* p1_entry_buffer = gtk_entry_buffer_new(NULL,-1);
    GtkEntryBuffer* p2_entry_buffer = gtk_entry_buffer_new(NULL,-1);


    //lecture du fichier ui
    gtk_builder_add_from_file(builder_object,"main.ui",NULL);
    gtk_builder_add_from_file(builder_object,"home.ui",NULL);
    //recuperation des objects dans variables
    
    //boutons home
    
    //fenetre du jeu
    GtkWidget* main_window = GTK_WIDGET(gtk_builder_get_object(builder_object,"main_window"));
    GtkWidget* home_window = GTK_WIDGET(gtk_builder_get_object(builder_object,"home_window"));
    // grille générale
    GObject* main_grid = gtk_builder_get_object(builder_object,"main_grid");
    //grille des cases du jeu
    GObject* game_grid = gtk_builder_get_object(builder_object,"game_grid");
    // nom des jouers
    GObject* p1_label = gtk_builder_get_object(builder_object,"p1_label");
    GObject* p2_label = gtk_builder_get_object(builder_object,"p2_label");
    //input des actions des joueurs
    GObject* p1_entry = gtk_builder_get_object(builder_object,"p1_entry");
    GObject* p2_entry = gtk_builder_get_object(builder_object,"p2_entry");
    //boutons envoyer des inputs
    GObject* p1_entry_send_button = gtk_builder_get_object(builder_object,"p1_entry_send_button");
    GObject* p2_entry_send_button = gtk_builder_get_object(builder_object,"p2_entry_send_button");
    //autres boutons
    GObject* button_quit_main = gtk_builder_get_object(builder_object,"button_quit_main");
    GObject* button_quit_home = gtk_builder_get_object(builder_object,"button_quit_home");
    GObject* rules_button = gtk_builder_get_object(builder_object,"rules_button");
    GObject* button_home= gtk_builder_get_object(builder_object,"home_button");
    GObject* button_serveur = gtk_builder_get_object(builder_object,"button_serveur");
    GObject* button_local = gtk_builder_get_object(builder_object, "button_local");
    
    // tour atteint
    game_info_label = gtk_builder_get_object(builder_object,"game_info_label");
    
    //associer la fenetre à l'application
    gtk_window_set_application (GTK_WINDOW(main_window),app);
    gtk_window_set_application (GTK_WINDOW(home_window),app);
    //afficher fenetre
    gtk_window_set_title(GTK_WINDOW(main_window), "HEX");
 
    
    // normalisation taille des cases de jeu
    gtk_grid_set_column_homogeneous(GTK_GRID(game_grid), true);
    gtk_grid_set_row_homogeneous(GTK_GRID(game_grid), true);

    // remplissage de game_grid
    GtkWidget *gui_cell_array[SIZE_TAB_GUI * SIZE_TAB_GUI]; // liste des boutons en 1 dimension, voir map_2d_to_1d

    for (int row = 1; row < SIZE_TAB_GUI; row++) // on débute par 1 car 1ere ligne contient les labels
    {
        for (int col = 1; col < SIZE_TAB_GUI; col++)// on débute par 1 car 1ere colonne contient les labels
        {
            // char idx[11] = {}; // debug
            int i = map_2d_to_1d(row, col);
            printf("(%c%d)-> %d\n",row+64,col-1,i); // +64 et -1 car debute par 1 pas 0
            gui_cell_array[i] = gtk_button_new();
            // propriétés des boutons
            gtk_widget_set_vexpand(gui_cell_array[i],false);
            gtk_widget_set_hexpand(gui_cell_array[i],false);
            //enlever arriere plan
            gtk_button_set_has_frame(GTK_BUTTON(gui_cell_array[i]),false);
            //initialisation case vide
            gtk_button_set_child(GTK_BUTTON(gui_cell_array[i]), gtk_image_new_from_file(PATH_EMPTY_CELL));
            
            g_signal_connect(gui_cell_array[i], "clicked", G_CALLBACK(set_cell_color), &tour);
            //ajout du bouton à la grille
            gtk_grid_attach(GTK_GRID(game_grid), gui_cell_array[i], col, row, 1, 1);
        }
    }
    
     
    //open home window
    gtk_widget_show(GTK_WIDGET(home_window));
    //open main window
    g_signal_connect (button_local, "clicked", G_CALLBACK (open_window), main_window);
    g_signal_connect (button_serveur, "clicked", G_CALLBACK (open_window), main_window);
    g_signal_connect (button_home, "clicked", G_CALLBACK (open_window), home_window);
    
    //boutton quit
    g_signal_connect (button_quit_main, "clicked", G_CALLBACK (quit_application), main_window);
    g_signal_connect (button_quit_home, "clicked", G_CALLBACK (quit_application), home_window);
    
}



int main(int argc, char **argv)
{
    GtkApplication *app;
    int status;
    //tableau[SIZE][SIZE]=init(tableau[SIZE][SIZE]);

    app = gtk_application_new("org.immersion.gr2", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
    status = g_application_run(G_APPLICATION(app), argc, argv);
    
    g_object_unref(app);

    return status;
}


