#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
int main() {
    char choix[20];
 
    printf("Choose the following option (server/client)");
    scanf("%s", choix);
 
    if (strcmp(choix, "client") == 0) {
        printf("Launching mainclient.c...\n");
        system("gcc mainclient.c lib/*.c -o mainclient.exe && ./mainclient.exe"); // Exécuter mainclient
    } else if (strcmp(choix, "server") == 0) {
        printf("Launching de mainserv.c...\n");
        system("gcc mainserv.c lib/*.c -o mainserv.exe && ./mainserv.exe"); // Exécuter mainserv
    } else {
        printf("Invalid choice...\n");
        return 1;
    }
 
    return 0;
}