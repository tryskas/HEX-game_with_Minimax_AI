/**
* \file server.c
* \brief Creates the server for the game
*
*
*/


#ifndef SERVEUR
#define SERVEUR

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <netdb.h>
#include "../lib/const.h"
    #define PORT 1234

 

// Functions that gets the IPV4 adress of the computer
char* get_local_ip_address() {
    struct ifaddrs *ifaddr, *ifa;
    char *ip_address = NULL;

    if (getifaddrs(&ifaddr) == -1) {
        perror("getifaddrs");
        return NULL;
    }

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr == NULL || ifa->ifa_addr->sa_family != AF_INET)
            continue;

        struct sockaddr_in *ipv4 = (struct sockaddr_in *)ifa->ifa_addr;
        ip_address = strdup(inet_ntoa(ipv4->sin_addr));
        break;
    }

    freeifaddrs(ifaddr);

    return ip_address;
}

// Function to send the data to the client
void send_data_to_client(int client_socket, const char* data) {
    ssize_t bytes_sent;
 
    // Sends the data to the client
    bytes_sent = send(client_socket, data, strlen(data), 0);
    if (bytes_sent < 0) {
        perror("Error while sending the data to client");
        close(client_socket);
    }
}

void handle_client(int client_socket,char* buffer) {
    ssize_t bytes_received;
 
    // Waits for data from the client
    bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
    if (bytes_received < 0) {
        //perror("Error while receiving the message from client");
        return;
    }
 

	// Prints the message received from the client
	printf("Message of client : %s\n", buffer);
	
}


int mainserv() {
    #define PORT 1234
    /*printf("SIUUUUUUUU");
    char* local_ip = get_local_ip_address();
    if (local_ip != NULL) {
        printf("Local IP Address: %s\n", local_ip);
        free(local_ip);
    } else {
        printf("Failed to retrieve local IP address.\n");
    }
    */

    
    // Prints the IPV4 adress of the computer


    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
 
    // Create a server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Error while creating the server socket");
        exit(EXIT_FAILURE);
    }
    // Avoids getting the error 'Address already in use' if reusing the same port
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &(int){ 1 }, sizeof(int));
 
    // Configures the adress of the server
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
 
    // Bind the server socket to the specified adress and port
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error while binding the server socket");
        close(server_socket);
        exit(EXIT_FAILURE);
    }
 
    // Listens to the server
    if (listen(server_socket, MAX_CLIENTS) == -1) {
        perror("Error listening to the server");
        close(server_socket);
        exit(EXIT_FAILURE);
    }
 
    printf("Server waiting for connections\n");
    
    // Loop until connection then return the client socket
    while (1) {
        // Accept an entering connection
        client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_addr_len);
        if (client_socket == -1) {
            perror("Error while accepting the client");
            continue;
        }
		return client_socket;
    }
 
    // Close the server socket (the program will not reach here)
    close(server_socket);
 
    return 0;
}

#endif