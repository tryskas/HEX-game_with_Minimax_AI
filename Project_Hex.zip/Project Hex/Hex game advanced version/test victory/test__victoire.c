#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

char lettre1[20]="";
int lettre2=0;
int fin=0;
int tableau[6][6];
int valtableau =0;
int val=1;
int tour=1;
int scoreR=0;
int scoreB=0;

#define SIZE 6

int grille[6][6]={{1,0,2,0,0,0},
            {2,1,0,0,0,0},
            {0,0,1,0,0,0},
            {0,0,0,1,0,2},
            {0,0,2,0,1,0},
            {0,0,2,0,0,1}};





// Structure pour stocker le résultat de valable
struct ResultatValable {
    int valide;
    int lettre1;
    int lettre2;
};

struct ResultatValable valable(const char prompt[], int tableau[][SIZE]) {
    struct ResultatValable resultat;
    resultat.valide = 0;

    char *alphabettableau = "ABCDEF";
    char *alphabetpetittableau = "abcdef";
    char *nombretableau = "123456";

    char lettre1bis = (char)(prompt[0]);
    char lettre2bis = (char)(prompt[1]);

    char *trouve1 = strchr(alphabettableau, lettre1bis);
    char *trouve1bis = strchr(alphabetpetittableau, lettre1bis);
    char *trouve2 = strchr(nombretableau, lettre2bis);

    int chiffre1 = (int)(lettre1bis);
    int chiffre2 = (int)(lettre2bis);

    int taille = strlen(prompt);


    if ((trouve1 != NULL||trouve1bis != NULL) && (taille == 2)) {
        if (trouve2 != NULL) {
            //printf("test %d %d %d %d\n", *trouve1, *trouve2, chiffre1, chiffre2);
            
            if (trouve1bis != NULL) { // cas lettre minuscule
                int indexLettre1min = lettre1bis - 'a';
                int indexLettre2min = *trouve2 -'1';
                int casetableau = tableau[indexLettre2min][indexLettre1min];
                if (casetableau == 0) {
                    // la case est vide donc on peut faire des trucs
                    resultat.valide = 1;
                    resultat.lettre1 = indexLettre1min;
                    resultat.lettre2 = indexLettre2min;
                }
            } else { // cas lettre majuscule
                int indexLettre1maj = lettre1bis - 'A';
                int indexLettre2maj = *trouve2 -'1';
                int casetableau = tableau[indexLettre2maj][indexLettre1maj];
                if (casetableau == 0) {
                    // la case est vide donc on peut faire des trucs
                    resultat.valide = 1;
                    resultat.lettre1 = indexLettre1maj;
                    resultat.lettre2 = indexLettre2maj;
                }
            }
        }
    }
    //printf("resultat = %d %d %d \n",resultat.valide,resultat.lettre1,resultat.lettre2);
    return resultat;
}

void affichage(int tableau[SIZE][SIZE],int tour){
    
    int i,j=0;
    printf("NOUS SOMMES AU %d IEME TOUR\n----------%d:%d----------\n",tour,scoreR,scoreB);
    for(i=0; i<SIZE; ++i){
        for(j=0; j<SIZE; ++j){
            printf("%d ",tableau[i][j]);
        }
        printf("\n");
    }


}

int editTableau(int tableau[][SIZE],int indexlettre1,int indexlettre2,int tour) {
    int val =0;
    if (tour%2==0){
        val=2;
    }else{
        val=1;
    }
    tableau[indexlettre2][indexlettre1]=val;
    return tableau[SIZE][SIZE];
}

int asWon(int tab[SIZE][SIZE], int x, int y, int player, int visited [6][6])
{ 
    if ((x < 0 || x>= SIZE) || (y<0 || y >= SIZE))
    {
        return 0;
    }

    visited[x][y] = 1;

    if (player == 1 && x == 5)
    {
        return 1;
    }

    if (player == 2 && y == 5)
    {
        return 1;
    }


    for (int yCoo = y-1; yCoo <= y+1; yCoo++)
    {
        for (int xCoo = x-1; xCoo <= x+1; xCoo++)
        {
            if (tab[xCoo][yCoo] == player && visited[xCoo][yCoo] == 0)
            {
                if (asWon (tab, xCoo, yCoo, player, visited) == 1)
                {
                    return 1;
                }
            }
        }
    }

    return 0;
    
}

int verificationVictory (int tab[][SIZE], int player)
{
    int visited [SIZE][SIZE] = {{0}};
    if (player == 1)
    {
        for (int j = 0; j < SIZE; j++)
        {
            if ((tab [0][j] == player) && (asWon(tab, 0, j, player, visited) == 1))
            {
                scoreB += 1;
                return 1;
            }
        }
    }

    if (player == 2)
    {
        for (int j = 0; j < SIZE; j++)
        {
            if ((tab [j][0] == player) && (asWon(tab, j, 0, player, visited) == 1))
            {
                scoreR += 1;
                return 1;
            }
        }
    }}

int test_victoire(int grille_a_tester[][SIZE]){
    int resultat = 1;
    if (verificationVictory(grille_a_tester, 1) == resultat)
        printf("test reussi");
    if (verificationVictory (grille_a_tester, 1) != resultat)
    
        printf("test echoue");
    
}

int main(){

 test_victoire(grille);

    return 0;
}