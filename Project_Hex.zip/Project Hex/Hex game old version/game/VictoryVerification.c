#include <stdio.h>
#include <stdlib.h>

const int LIGNES = 6;
const int COLONNES = 6;


void print_grid(int grid[LIGNES][COLONNES]);
void init_grid(int grid[LIGNES][COLONNES], int random);
int assert_coordinates(int i, int j);
void print_neighbors(int grid[LIGNES][COLONNES], int i, int j);
int winner(int player, int grid[LIGNES][COLONNES]);
int hasPath(int visited[LIGNES][COLONNES], int grid[LIGNES][COLONNES], int i, int j);

int main(int argc, char **argv){
    //int grid[LIGNES][COLONNES];
    int visited[LIGNES][COLONNES];
    //init_grid(grid, 1);
    init_grid(visited, 0);
    int grid[][6] = {{1, 0, 2, 1, 0, 0},{0, 1, 1, 0, 1, 0},{2, 2, 2, 0, 1, 2},{0, 0, 0, 0, 1, 0},{0, 0, 0, 0, 1, 2},{0, 0, 0, 0, 1, 1}};
    print_grid(grid);
    printf("Neighbors of (0, 0):\n");
    print_neighbors(grid, 0, 0);
    printf("Neighbors of (2, 3):\n");
    print_neighbors(grid, 2, 3);
    printf("---------- START SEARCH ----------");
    int foundPath = 0;
    // Try starting from each row in the first column
    for (int i = 0; i < LIGNES; i++) {
        if (grid[i][0] == 1) {
            if (hasPath(visited, grid, i, 0)) {;
                foundPath = 1;
                break;
            }
        }
    }
    if (foundPath) {
        printf("Player 1 has won.\n");
    } else {
        printf("There is no path using only 1s from the first column to the last column.\n");
    }

    return 0;
}


void print_grid(int grid[LIGNES][COLONNES]){
    for (int i = 0; i < LIGNES; i++){
        for (int j = 0; j < COLONNES; j++){
            printf("%d", grid[i][j]);
        }
        printf("\n");
    }
}

void init_grid(int grid[LIGNES][COLONNES], int random){
    for (int i = 0; i < LIGNES; i++){
        for (int j = 0; j < COLONNES; j++){
            if (random){
                grid[i][j] = rand() % 3;
            }else{
                grid[i][j] = 0;
            }
        }
    }
}

int assert_coordinates(int i, int j){
    return (i >= 0 && i < LIGNES && j >= 0 && j < COLONNES);
}

void print_neighbors(int grid[LIGNES][COLONNES], int i, int j){
    for (int l = -1; l < 2; l++){
        for (int k = -1; k < 2; k++){
            if (assert_coordinates(i + l, j + k) && (l != 0 || k != 0)){
                printf("(%d, %d) : %d\n", i + l, j + k, grid[i+l][j+k]);
            }
        }
    }
}


int hasPath(int visited[LIGNES][COLONNES], int grid[LIGNES][COLONNES], int i, int j) {
    if (j == COLONNES - 1) {
        return 1;
    }

    visited[i][j] = 1;

    int rowMoves[] = {-1, 1, 0, 0, -1, 1, -1, 1};
    int colMoves[] = {0, 0, -1, 1, 1, 1, -1, -1};

    for (int l = 0; l < 8; l++) {
        int newRow = i + rowMoves[l];
        int newCol = j + colMoves[l];
        if (assert_coordinates(newRow, newCol) && !visited[newRow][newCol] && grid[newRow][newCol] == 1 && hasPath(visited, grid, newRow, newCol)) {
            return 1;
        }
    }
    
    return 0;
}


int winner(int player, int grid[LIGNES][COLONNES]){

    return 0;
}