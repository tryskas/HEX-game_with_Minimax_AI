#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    compte_a_rebours;
   

    return 0;
}

void compte_a_rebours() {
        int seconds = 20;

    printf("Compte à rebours de %d secondes :\n", seconds);

    while (seconds > 0) {
        printf("%d\n", seconds);
        sleep(1); // Attendre 1 seconde
        seconds--;
    }

    printf("Temps écoulé !\n");
}
