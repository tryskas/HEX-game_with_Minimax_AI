var searchData=
[
  ['buffer_5fsize_0',['BUFFER_SIZE',['../mainclient_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;mainclient.c'],['../client_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;client.c'],['../server_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;server.c']]]
];
