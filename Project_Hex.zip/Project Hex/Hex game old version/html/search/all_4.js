var searchData=
[
  ['edittab_2ec_0',['editTab.c',['../edit_tab_8c.html',1,'']]],
  ['edittableau_1',['editTableau',['../game_2fonction_8c.html#a7fb56e3a78bc88ed0759c6e8e9607d54',1,'editTableau(int tableau[][SIZE], int indexlettre1, int indexlettre2, int tour, int val):&#160;fonction.c'],['../propre2_2main_2game_2fonction_8c.html#aac4c2926a456b2e4cec720ebd01a4198',1,'editTableau(int tableau[][SIZE], int indexlettre1, int indexlettre2, int tour):&#160;fonction.c'],['../edit_tab_8c.html#aac4c2926a456b2e4cec720ebd01a4198',1,'editTableau(int tableau[][SIZE], int indexlettre1, int indexlettre2, int tour):&#160;editTab.c'],['../header_8h.html#aac4c2926a456b2e4cec720ebd01a4198',1,'editTableau(int tableau[][SIZE], int indexlettre1, int indexlettre2, int tour):&#160;fonction.c']]],
  ['evaluate_2',['evaluate',['../propre2_2main_2game_2fonction_8c.html#a7b690dd4b90ec43bed857c3151413b80',1,'evaluate(int board[][SIZE], int player):&#160;fonction.c'],['../header_8h.html#a7b690dd4b90ec43bed857c3151413b80',1,'evaluate(int board[][SIZE], int player):&#160;fonction.c'],['../_mini_max_8c.html#a7b690dd4b90ec43bed857c3151413b80',1,'evaluate(int board[][SIZE], int player):&#160;MiniMax.c']]],
  ['example4_2ec_3',['example4.c',['../example4_8c.html',1,'']]]
];
