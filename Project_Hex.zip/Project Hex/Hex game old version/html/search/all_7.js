var searchData=
[
  ['handle_5fclient_0',['handle_client',['../server_8c.html#abfd424b812797c474986a3aeeaf520b8',1,'server.c']]],
  ['handle_5fserver_1',['handle_server',['../client_8c.html#a6fab8aa26e10f802815737f0bf6beb03',1,'client.c']]],
  ['header_2eh_2',['header.h',['../header_8h.html',1,'']]]
];
