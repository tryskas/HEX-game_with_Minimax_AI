var searchData=
[
  ['resultatvalable_0',['ResultatValable',['../struct_resultat_valable.html',1,'']]]
];
