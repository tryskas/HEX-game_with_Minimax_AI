var searchData=
[
  ['scoreb_0',['scoreB',['../game_2fonction_8c.html#ab29f6302a4f6fb10c1d1e737157574eb',1,'scoreB():&#160;fonction.c'],['../propre2_2main_2game_2fonction_8c.html#ab29f6302a4f6fb10c1d1e737157574eb',1,'scoreB():&#160;fonction.c']]],
  ['scorer_1',['scoreR',['../game_2fonction_8c.html#a94874cfd7ef62e925fe84001ef6393d3',1,'scoreR():&#160;fonction.c'],['../propre2_2main_2game_2fonction_8c.html#a94874cfd7ef62e925fe84001ef6393d3',1,'scoreR():&#160;fonction.c']]],
  ['searchresult_2',['SearchResult',['../struct_search_result.html',1,'']]],
  ['send_5fdata_5fto_5fclient_3',['send_data_to_client',['../server_8c.html#aa8023811a33fb98d6361cbf530ef4e3d',1,'server.c']]],
  ['send_5fdata_5fto_5fserver_4',['send_data_to_server',['../client_8c.html#a05393ea0bf1e0ccfcd95481344dec69f',1,'client.c']]],
  ['server_2ec_5',['server.c',['../server_8c.html',1,'']]],
  ['server_5fip_6',['SERVER_IP',['../client_8c.html#a28d06fc286f28044ed3380969700ff3f',1,'client.c']]],
  ['server_5fport_7',['SERVER_PORT',['../client_8c.html#ac42367fe5c999ec6650de83e9d72fe8c',1,'client.c']]],
  ['sideconnected_8',['sideConnected',['../propre2_2main_2game_2fonction_8c.html#a86dc28bbec563285bf35462d9ac4f2a7',1,'sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;fonction.c'],['../verify_victory_8c.html#a86dc28bbec563285bf35462d9ac4f2a7',1,'sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;verifyVictory.c']]],
  ['size_9',['SIZE',['../game_2fonction_8c.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;fonction.c'],['../example4_8c.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;example4.c'],['../interface_8c.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;interface.c'],['../propre2_2main_2game_2fonction_8c.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;fonction.c'],['../header_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;header.h']]],
  ['size_5ftab_5fgui_10',['SIZE_TAB_GUI',['../interface_8c.html#a3f733e54685a2cbfc5be012764526e87',1,'interface.c']]]
];
