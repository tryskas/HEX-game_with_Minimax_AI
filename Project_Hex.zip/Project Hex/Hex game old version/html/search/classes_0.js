var searchData=
[
  ['move_0',['Move',['../struct_move.html',1,'']]]
];
