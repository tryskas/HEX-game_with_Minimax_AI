var searchData=
[
  ['max_5fclients_0',['MAX_CLIENTS',['../server_8c.html#a0a8f91f93d75a07f0ae45077db45b3eb',1,'server.c']]]
];
