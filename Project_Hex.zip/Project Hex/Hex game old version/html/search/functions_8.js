var searchData=
[
  ['send_5fdata_5fto_5fclient_0',['send_data_to_client',['../server_8c.html#aa8023811a33fb98d6361cbf530ef4e3d',1,'server.c']]],
  ['send_5fdata_5fto_5fserver_1',['send_data_to_server',['../client_8c.html#a05393ea0bf1e0ccfcd95481344dec69f',1,'client.c']]],
  ['sideconnected_2',['sideConnected',['../propre2_2main_2game_2fonction_8c.html#a86dc28bbec563285bf35462d9ac4f2a7',1,'sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;fonction.c'],['../verify_victory_8c.html#a86dc28bbec563285bf35462d9ac4f2a7',1,'sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;verifyVictory.c']]]
];
