var searchData=
[
  ['valable_0',['valable',['../game_2fonction_8c.html#ab3632df7dad91e2d2361c508ce13a2b4',1,'valable(const char prompt[], int tableau[][SIZE]):&#160;fonction.c'],['../propre2_2main_2game_2fonction_8c.html#a0e70195a6cc13b64f8590d1318fc53db',1,'valable(const char prompt[], int tableau[][6]):&#160;fonction.c'],['../edit_tab_8c.html#ab3632df7dad91e2d2361c508ce13a2b4',1,'valable(const char prompt[], int tableau[][SIZE]):&#160;editTab.c'],['../header_8h.html#ab3632df7dad91e2d2361c508ce13a2b4',1,'valable(const char prompt[], int tableau[][SIZE]):&#160;fonction.c']]],
  ['verificationvictory_1',['verificationVictory',['../game_2fonction_8c.html#adcee258828b6e7dd4857733b87f4fda8',1,'fonction.c']]],
  ['verifyvictory_2',['verifyVictory',['../propre2_2main_2game_2fonction_8c.html#a1c671bd939a82e7736e403fc01ee6a08',1,'verifyVictory(int tab[][SIZE], int player):&#160;fonction.c'],['../header_8h.html#a1c671bd939a82e7736e403fc01ee6a08',1,'verifyVictory(int tab[][SIZE], int player):&#160;fonction.c'],['../verify_victory_8c.html#a1c671bd939a82e7736e403fc01ee6a08',1,'verifyVictory(int tab[][SIZE], int player):&#160;verifyVictory.c']]]
];
