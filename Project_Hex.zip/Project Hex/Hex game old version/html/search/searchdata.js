var indexSectionsWithContent =
{
  0: "abcdefghilmprstv",
  1: "mrs",
  2: "g",
  3: "acefghimsv",
  4: "acefghimsv",
  5: "cdfgilmstv",
  6: "bgimps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros"
};

