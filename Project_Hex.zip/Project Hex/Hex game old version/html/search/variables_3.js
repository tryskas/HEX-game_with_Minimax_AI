var searchData=
[
  ['game_5fgrid_0',['game_grid',['../interface_8c.html#a5204ef06b4eb721d8435f56f6de485a4',1,'interface.c']]],
  ['game_5finfo_5flabel_1',['game_info_label',['../interface_8c.html#a299ce620af0e3206bd77f32ff7aa2019',1,'interface.c']]]
];
