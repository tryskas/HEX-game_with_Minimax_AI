var searchData=
[
  ['minimaxcopytableau_0',['MiniMaxCopyTableau',['../propre2_2main_2game_2fonction_8c.html#a24ff9a97795c939b8021ce2ded5c8e80',1,'fonction.c']]],
  ['move_1',['move',['../struct_search_result.html#aa3a651c1e16fe4649e3a7b7ec33c606d',1,'SearchResult']]]
];
