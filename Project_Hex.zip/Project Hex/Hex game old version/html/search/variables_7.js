var searchData=
[
  ['scoreb_0',['scoreB',['../game_2fonction_8c.html#ab29f6302a4f6fb10c1d1e737157574eb',1,'scoreB():&#160;fonction.c'],['../propre2_2main_2game_2fonction_8c.html#ab29f6302a4f6fb10c1d1e737157574eb',1,'scoreB():&#160;fonction.c']]],
  ['scorer_1',['scoreR',['../game_2fonction_8c.html#a94874cfd7ef62e925fe84001ef6393d3',1,'scoreR():&#160;fonction.c'],['../propre2_2main_2game_2fonction_8c.html#a94874cfd7ef62e925fe84001ef6393d3',1,'scoreR():&#160;fonction.c']]]
];
