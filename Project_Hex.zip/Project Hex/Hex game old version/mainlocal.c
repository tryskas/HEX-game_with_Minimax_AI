/**
* \file mainlocal.c
* \brief Launch the game in local mode
*
*
*/

// Includes all the headers and libraries needed
#include "../lib/header.h"
#include <stdio.h>
#include <limits.h>

char letter1[20] = "";
int end = 0;
int turn = 1;

int game_board[SIZE][SIZE];

int main() {
    game_board[SIZE][SIZE] = init(game_board);
    printing(game_board, turn);
    // Main loop for the game
    while (end != 1) {

        // Asking for the player's move
        printf("Which case do you want to color ? ");
        scanf(" %2s", &letter1[0]);
            
        // Checks if the move wanted by the player is doable
        struct ResultValidity result = validity(&letter1[0], game_board);

        if (result.valid) {
            game_board[SIZE][SIZE] = editgame_board(game_board, result.column, result.line,turn);
            turn++;
        } else {
            printf("\nMove invalid...\n\n\n");
        }

        // Checks if there is a winner
        if (verifyVictory(game_board, (turn % 2) + 1) == 1) {
            printf("\n\t\tThe player %d WON !!!\n", turn%2 + 1);
            end = 1; // Puts an end to the game if there is a winner

        }
        else if (verifyVictory(game_board, (turn%2)+1) == 2)
        {
        printf("\n\t\tIt's a tie... too bad...");
        end++;
        }
        else {
            printf("The player %d didn't won... for now...\n", turn%2 + 1);
        }

        // Prints the game_board in the terminal
        printing(game_board, turn);
    }

    return 0;
}
