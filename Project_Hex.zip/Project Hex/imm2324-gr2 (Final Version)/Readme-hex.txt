+---------------------------------------------------------------------------------------------
| Compilation
+---------------------------------------------------------------------------------------------

At the root core of the program
     Compilation, creates the executable ./hex
	$ make

     Documentations : production of the documents under ./docs and opening in default browser
	$ make docs
     $ make open_docs

+---------------------------------------------------------------------------------------------
| Usage
+---------------------------------------------------------------------------------------------

$ ./hex [options]
$ ./hex -s pppp
$ ./hex -c hh.hh.hh.hh:pppp
$ ./hex -l bleu
$ ./hex -l rouge

+---------------------------------------------------------------------------------------------
| Problems encountered
+---------------------------------------------------------------------------------------------

- No implementation of the GUI of the game in Online mode because of time and complexity of the task.

- Also because of time and the way gtk works, we couldn't show in real time the moves made by the 2 AIs in local mode (with GUI).

- Problem while wanting to display the computer's IPV4 adress (not localhost) at the start of the server. What is strange is that it works fine on older versions of the project but it returns a segfault on the finished version. There isn't any variables or functions that may have changed, it's just a print function using the same librairies that the program creating the server.
