var searchData=
[
  ['update_5fgui_5fturn_0',['update_gui_turn',['../comments_8h.html#ab175ad70def535017332eca48554225b',1,'update_gui_turn(GtkWidget *widget, gpointer p_tour):&#160;fct_gui.c'],['../fct__gui_8c.html#ab175ad70def535017332eca48554225b',1,'update_gui_turn(GtkWidget *widget, gpointer p_tour):&#160;fct_gui.c'],['../header__gui_8h.html#ab175ad70def535017332eca48554225b',1,'update_gui_turn(GtkWidget *widget, gpointer p_tour):&#160;fct_gui.c']]],
  ['update_5fturn_5flabel_1',['update_turn_label',['../comments_8h.html#ac0b36908701287fc78add244c31fdf68',1,'update_turn_label():&#160;fct_gui.c'],['../fct__gui_8c.html#ac0b36908701287fc78add244c31fdf68',1,'update_turn_label():&#160;fct_gui.c'],['../header__gui_8h.html#ac0b36908701287fc78add244c31fdf68',1,'update_turn_label():&#160;fct_gui.c']]]
];
