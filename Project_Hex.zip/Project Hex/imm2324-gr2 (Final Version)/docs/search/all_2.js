var searchData=
[
  ['calculateaveragedistancetoedges_0',['calculateAverageDistanceToEdges',['../comments_8h.html#ad8770589c80d35a4fc4b39ece5941073',1,'calculateAverageDistanceToEdges(int game_board[][SIZE], int player):&#160;fct_gui.c'],['../fct__gui_8c.html#ad8770589c80d35a4fc4b39ece5941073',1,'calculateAverageDistanceToEdges(int game_board[][SIZE], int player):&#160;fct_gui.c'],['../header__gui_8h.html#ad8770589c80d35a4fc4b39ece5941073',1,'calculateAverageDistanceToEdges(int game_board[][SIZE], int player):&#160;fct_gui.c'],['../alpha_beta_8c.html#ad8770589c80d35a4fc4b39ece5941073',1,'calculateAverageDistanceToEdges(int game_board[][SIZE], int player):&#160;alphaBeta.c']]],
  ['calculer_5fpremiere_5faction_1',['calculer_premiere_action',['../comments_8h.html#a8b290f222846b1efa694012472fd34a7',1,'calculer_premiere_action():&#160;fct_gui.c'],['../fct__gui_8c.html#adbbcac5aca02ccc7aea46aa2685c9cfb',1,'calculer_premiere_action():&#160;fct_gui.c'],['../header__gui_8h.html#adbbcac5aca02ccc7aea46aa2685c9cfb',1,'calculer_premiere_action():&#160;fct_gui.c']]],
  ['centerx_2',['centerX',['../const_8h.html#a91f81237f4e39a0977991363be127c9b',1,'centerX():&#160;const.h'],['../globals__gui_8h.html#a91f81237f4e39a0977991363be127c9b',1,'centerX():&#160;globals_gui.h']]],
  ['centery_3',['centerY',['../const_8h.html#acf43aa92618c0e12e568708f51207179',1,'centerY():&#160;const.h'],['../globals__gui_8h.html#acf43aa92618c0e12e568708f51207179',1,'centerY():&#160;globals_gui.h']]],
  ['cleanstring_4',['cleanstring',['../client_8c.html#ad6f7514e5942b8405688a9dd6cd0f72d',1,'client.c']]],
  ['client_5',['CLIENT',['../client_8c.html#af19f26460d89cfb3f212f4b0a44882e8',1,'client.c']]],
  ['client_2ec_6',['client.c',['../client_8c.html',1,'']]],
  ['column_7',['column',['../struct_result_validity.html#a60dae4c6e78188cd718b696e4f08fc71',1,'ResultValidity::column()'],['../struct_resultat_valable.html#a60dae4c6e78188cd718b696e4f08fc71',1,'ResultatValable::column()'],['../struct_move.html#a60dae4c6e78188cd718b696e4f08fc71',1,'Move::column()']]],
  ['comments_2eh_8',['comments.h',['../comments_8h.html',1,'']]],
  ['const_2eh_9',['const.h',['../const_8h.html',1,'']]],
  ['controleur_5fjeu_10',['controleur_jeu',['../comments_8h.html#a5a6e82e9e2952a43b0d6b75b88d350d6',1,'controleur_jeu(struct ResultatValable *p_prompt):&#160;fct_gui.c'],['../fct__gui_8c.html#a5a6e82e9e2952a43b0d6b75b88d350d6',1,'controleur_jeu(struct ResultatValable *p_prompt):&#160;fct_gui.c'],['../header__gui_8h.html#a5a6e82e9e2952a43b0d6b75b88d350d6',1,'controleur_jeu(struct ResultatValable *p_prompt):&#160;fct_gui.c']]],
  ['countmobility_11',['countMobility',['../header_8h.html#aec922ec8515054c54710d5e3cf8eaa9c',1,'header.h']]]
];
