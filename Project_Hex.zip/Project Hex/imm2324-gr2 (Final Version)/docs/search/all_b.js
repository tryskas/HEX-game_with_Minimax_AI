var searchData=
[
  ['p1_5fentry_5fbuffer_0',['p1_entry_buffer',['../fct__gui_8c.html#a55c39f863edebbb3e78f564225149cb2',1,'p1_entry_buffer():&#160;fct_gui.c'],['../globals__gui_8h.html#a55c39f863edebbb3e78f564225149cb2',1,'p1_entry_buffer():&#160;fct_gui.c']]],
  ['p1_5fentry_5fsend_5fbutton_1',['p1_entry_send_button',['../fct__gui_8c.html#a76986dd9893939f615cbcb3845f4336b',1,'p1_entry_send_button():&#160;fct_gui.c'],['../globals__gui_8h.html#a76986dd9893939f615cbcb3845f4336b',1,'p1_entry_send_button():&#160;fct_gui.c']]],
  ['p2_5fentry_5fbuffer_2',['p2_entry_buffer',['../fct__gui_8c.html#ae8304e470e2f7ccf2a53c86e8f5cbd3f',1,'p2_entry_buffer():&#160;fct_gui.c'],['../globals__gui_8h.html#ae8304e470e2f7ccf2a53c86e8f5cbd3f',1,'p2_entry_buffer():&#160;fct_gui.c']]],
  ['p2_5fentry_5fsend_5fbutton_3',['p2_entry_send_button',['../globals__gui_8h.html#aeafc48a0731869075875a39f594fd20d',1,'p2_entry_send_button():&#160;fct_gui.c'],['../fct__gui_8c.html#aeafc48a0731869075875a39f594fd20d',1,'p2_entry_send_button():&#160;fct_gui.c']]],
  ['path_5fempty_5fcell_4',['PATH_EMPTY_CELL',['../globals__gui_8h.html#a64ed88c1734ebe4dc5151622c3b1e008',1,'globals_gui.h']]],
  ['path_5fp1_5fcell_5',['PATH_P1_CELL',['../globals__gui_8h.html#a606f58bda2431c1dd0eeacff64be7cdb',1,'globals_gui.h']]],
  ['path_5fp2_5fcell_6',['PATH_P2_CELL',['../globals__gui_8h.html#a3aa90074ed41137a5832a4f32dbe3b49',1,'globals_gui.h']]],
  ['print_5fhello_7',['print_hello',['../comments_8h.html#ae9a1050597c0bb2e6e90a768eb3d3583',1,'print_hello(GtkWidget *widget, gpointer data):&#160;fct_gui.c'],['../fct__gui_8c.html#ae9a1050597c0bb2e6e90a768eb3d3583',1,'print_hello(GtkWidget *widget, gpointer data):&#160;fct_gui.c'],['../header__gui_8h.html#ae9a1050597c0bb2e6e90a768eb3d3583',1,'print_hello(GtkWidget *widget, gpointer data):&#160;fct_gui.c']]],
  ['printing_8',['printing',['../header_8h.html#a201ffb923ad8f0085fb33596a2c109ee',1,'printing(int game_board[SIZE][SIZE], int turn):&#160;printing_board.c'],['../printing__board_8c.html#a0ff0d0ac06f9ff2f9406b43895d96edc',1,'printing(int tableau[SIZE][SIZE], int tour):&#160;printing_board.c']]],
  ['printing_5fboard_2ec_9',['printing_board.c',['../printing__board_8c.html',1,'']]]
];
