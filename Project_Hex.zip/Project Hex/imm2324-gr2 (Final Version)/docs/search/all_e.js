var searchData=
[
  ['searchresult_0',['SearchResult',['../struct_search_result.html',1,'']]],
  ['send_5fdata_5fto_5fclient_1',['send_data_to_client',['../server_8c.html#aa8023811a33fb98d6361cbf530ef4e3d',1,'server.c']]],
  ['send_5fdata_5fto_5fserver_2',['send_data_to_server',['../client_8c.html#a05393ea0bf1e0ccfcd95481344dec69f',1,'client.c']]],
  ['server_2ec_3',['server.c',['../server_8c.html',1,'']]],
  ['serveur_4',['SERVEUR',['../server_8c.html#aeef0e3ba41fec73b731de55058a0e9a6',1,'server.c']]],
  ['sideconnected_5',['sideConnected',['../comments_8h.html#a86dc28bbec563285bf35462d9ac4f2a7',1,'sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;fct_gui.c'],['../fct__gui_8c.html#a86dc28bbec563285bf35462d9ac4f2a7',1,'sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;fct_gui.c'],['../header__gui_8h.html#a86dc28bbec563285bf35462d9ac4f2a7',1,'sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;fct_gui.c'],['../verify_victory_8c.html#a16495b431b6d401a88ea3fc4c71545b2',1,'sideConnected(int game_board[SIZE][SIZE], int x, int y, int player, int visited[6][6]):&#160;verifyVictory.c']]],
  ['size_6',['SIZE',['../globals__gui_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;globals_gui.h'],['../const_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;const.h']]],
  ['size_5ftab_5fgui_7',['SIZE_TAB_GUI',['../globals__gui_8h.html#a3f733e54685a2cbfc5be012764526e87',1,'globals_gui.h']]]
];
