var searchData=
[
  ['tour_0',['tour',['../fct__gui_8c.html#a4e97310c1e6f36bfc596401b2909d3a9',1,'tour():&#160;fct_gui.c'],['../globals__gui_8h.html#a4e97310c1e6f36bfc596401b2909d3a9',1,'tour():&#160;fct_gui.c']]],
  ['turn_1',['turn',['../mainclient_8c.html#aaefa47f4fdf865c2358c22b542a993e4',1,'turn():&#160;mainclient.c'],['../mainserv_8c.html#aaefa47f4fdf865c2358c22b542a993e4',1,'turn():&#160;mainserv.c']]]
];
