var searchData=
[
  ['move_0',['Move',['../struct_move.html',1,'']]],
  ['move_1',['move',['../structmove.html',1,'']]]
];
