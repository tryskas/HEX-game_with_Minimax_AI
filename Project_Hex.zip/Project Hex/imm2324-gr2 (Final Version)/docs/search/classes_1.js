var searchData=
[
  ['resultatvalable_0',['ResultatValable',['../struct_resultat_valable.html',1,'']]],
  ['resultvalidity_1',['ResultValidity',['../struct_result_validity.html',1,'']]]
];
