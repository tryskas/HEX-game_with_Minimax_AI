var searchData=
[
  ['searchresult_0',['SearchResult',['../struct_search_result.html',1,'']]]
];
