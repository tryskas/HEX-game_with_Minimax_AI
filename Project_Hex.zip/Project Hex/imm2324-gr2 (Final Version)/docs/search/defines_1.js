var searchData=
[
  ['centerx_0',['centerX',['../globals__gui_8h.html#a91f81237f4e39a0977991363be127c9b',1,'centerX():&#160;globals_gui.h'],['../const_8h.html#a91f81237f4e39a0977991363be127c9b',1,'centerX():&#160;const.h']]],
  ['centery_1',['centerY',['../globals__gui_8h.html#acf43aa92618c0e12e568708f51207179',1,'centerY():&#160;globals_gui.h'],['../const_8h.html#acf43aa92618c0e12e568708f51207179',1,'centerY():&#160;const.h']]],
  ['client_2',['CLIENT',['../client_8c.html#af19f26460d89cfb3f212f4b0a44882e8',1,'client.c']]]
];
