var searchData=
[
  ['max_5fclients_0',['MAX_CLIENTS',['../const_8h.html#a0a8f91f93d75a07f0ae45077db45b3eb',1,'const.h']]],
  ['min_1',['MIN',['../alpha_beta_8c.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'alphaBeta.c']]]
];
