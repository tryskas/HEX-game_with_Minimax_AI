var searchData=
[
  ['serveur_0',['SERVEUR',['../server_8c.html#aeef0e3ba41fec73b731de55058a0e9a6',1,'server.c']]],
  ['size_1',['SIZE',['../globals__gui_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;globals_gui.h'],['../const_8h.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;const.h']]],
  ['size_5ftab_5fgui_2',['SIZE_TAB_GUI',['../globals__gui_8h.html#a3f733e54685a2cbfc5be012764526e87',1,'globals_gui.h']]]
];
