var searchData=
[
  ['verifyvictory_2ec_0',['verifyVictory.c',['../verify_victory_8c.html',1,'']]]
];
