var searchData=
[
  ['print_5fhello_0',['print_hello',['../comments_8h.html#ae9a1050597c0bb2e6e90a768eb3d3583',1,'print_hello(GtkWidget *widget, gpointer data):&#160;fct_gui.c'],['../fct__gui_8c.html#ae9a1050597c0bb2e6e90a768eb3d3583',1,'print_hello(GtkWidget *widget, gpointer data):&#160;fct_gui.c'],['../header__gui_8h.html#ae9a1050597c0bb2e6e90a768eb3d3583',1,'print_hello(GtkWidget *widget, gpointer data):&#160;fct_gui.c']]],
  ['printing_1',['printing',['../header_8h.html#a201ffb923ad8f0085fb33596a2c109ee',1,'printing(int game_board[SIZE][SIZE], int turn):&#160;printing_board.c'],['../printing__board_8c.html#a0ff0d0ac06f9ff2f9406b43895d96edc',1,'printing(int tableau[SIZE][SIZE], int tour):&#160;printing_board.c']]]
];
