var indexSectionsWithContent =
{
  0: "abcdefghilmpqrstuvw",
  1: "mrs",
  2: "acefghimpsv",
  3: "aceghimpqrsuvw",
  4: "cdefglmptv",
  5: "bcdfimps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

