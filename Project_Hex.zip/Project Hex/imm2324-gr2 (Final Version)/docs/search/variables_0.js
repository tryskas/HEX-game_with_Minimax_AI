var searchData=
[
  ['column_0',['column',['../struct_move.html#a60dae4c6e78188cd718b696e4f08fc71',1,'Move::column()'],['../struct_resultat_valable.html#a60dae4c6e78188cd718b696e4f08fc71',1,'ResultatValable::column()'],['../struct_result_validity.html#a60dae4c6e78188cd718b696e4f08fc71',1,'ResultValidity::column()']]]
];
