var searchData=
[
  ['p1_5fentry_5fbuffer_0',['p1_entry_buffer',['../fct__gui_8c.html#a55c39f863edebbb3e78f564225149cb2',1,'p1_entry_buffer():&#160;fct_gui.c'],['../globals__gui_8h.html#a55c39f863edebbb3e78f564225149cb2',1,'p1_entry_buffer():&#160;fct_gui.c']]],
  ['p1_5fentry_5fsend_5fbutton_1',['p1_entry_send_button',['../fct__gui_8c.html#a76986dd9893939f615cbcb3845f4336b',1,'p1_entry_send_button():&#160;fct_gui.c'],['../globals__gui_8h.html#a76986dd9893939f615cbcb3845f4336b',1,'p1_entry_send_button():&#160;fct_gui.c']]],
  ['p2_5fentry_5fbuffer_2',['p2_entry_buffer',['../fct__gui_8c.html#ae8304e470e2f7ccf2a53c86e8f5cbd3f',1,'p2_entry_buffer():&#160;fct_gui.c'],['../globals__gui_8h.html#ae8304e470e2f7ccf2a53c86e8f5cbd3f',1,'p2_entry_buffer():&#160;fct_gui.c']]],
  ['p2_5fentry_5fsend_5fbutton_3',['p2_entry_send_button',['../fct__gui_8c.html#aeafc48a0731869075875a39f594fd20d',1,'p2_entry_send_button():&#160;fct_gui.c'],['../globals__gui_8h.html#aeafc48a0731869075875a39f594fd20d',1,'p2_entry_send_button():&#160;fct_gui.c']]]
];
