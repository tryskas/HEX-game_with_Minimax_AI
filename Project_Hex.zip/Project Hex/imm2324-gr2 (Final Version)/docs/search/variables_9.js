var searchData=
[
  ['valid_0',['valid',['../struct_resultat_valable.html#ac63b1f168765a53e565a8ba27f5469d1',1,'ResultatValable::valid()'],['../struct_result_validity.html#ac63b1f168765a53e565a8ba27f5469d1',1,'ResultValidity::valid()']]],
  ['value_1',['value',['../struct_search_result.html#ac4f474c82e82cbb89ca7c36dd52be0ed',1,'SearchResult']]]
];
