#ifndef HEADER_GUI_H
#define HEADER_GUI_H

#include "globals_gui.h"

typedef struct
{
    int line;
    int column;
}Move;


typedef struct
{
    int value;
    Move move;
} SearchResult;


// Structure to store the result of the validity test
struct ResultatValable {
    int valid;
    int column;
    int line;
};



// partie jeu
int calculer_premiere_action();
int calculateAverageDistanceToEdges(int game_board[][SIZE], int player);
int evaluate (int game_board[][SIZE], int player, int isClient);
SearchResult alphabeta(int game_board[][SIZE], int depth, int player, int alpha, int beta, int isClient);
void valable_struct(struct ResultatValable *action, int tableau[][SIZE]);
int editgame_board(int index_letter1, int index_letter2, int turn);
int controleur_jeu(struct ResultatValable *p_prompt);
int sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]);
int isValidPosition(int x, int y);
int verifyVictory(int tab[][SIZE], int player);


// utilitaires tableaux et autres
int readIntegerFromFile(const char *filename);
int map_2d_to_1d(int row, int col);
void int2Char(int d, char buffer[3]);
int map_1d_to_row(int idx);
int map_1d_to_col(int idx);
int get_pos_widget_in_array(GtkWidget *widget, GtkWidget **grid, int grid_size);


// gtk 
static void activate(GtkApplication *app, gpointer user_data);
void victoire_nul_update_label(int flag_win);
static void callback_entry_p1(GtkWidget *bouton_entry_p1, gpointer user_data);
/**
* |fn callback_entry_pt1(GtkWidget *bouton_entry_p1, gpointer user_data)
* |brief makes a precised move of the player 1 on the board
* |return nothing
**/
static void callback_entry_p2(GtkWidget *bouton_entry_p2, gpointer user_data);
/**
* |fn callback_entry_pt2(GtkWidget *bouton_entry_p2, gpointer user_data)
* |brief makes a precised move of the player 2 on the board
* |return nothing
**/
void update_turn_label();
/**
* |fn update_turn_label()
* |brief changes the number of the player who has to make a move everytime the other player does 
* |return nothing
**/
void print_hello(GtkWidget *widget, gpointer data);
void quit_application(GtkWidget *widget, gpointer gp_app);
static void open_window_local_jcj(GtkWidget *widget, gpointer data);
/**
* |fn open_window_local_jcj(GtkWidget *widget, gpointer data)
* |brief opens a window to start the game between two players 
* |return nothing
**/
static void open_window_local_ia(GtkWidget *widget, gpointer data);
/**
* |fn open_window_local_ia(GtkWidget *widget, gpointer data)
* |brief opens a window to start the game between a human player and AI 
* |return nothing
**/
static void open_window_special_ia(GtkWidget *widget, gpointer data);
/**
* |fn open_window_special_ia(GtkWidget *widget, gpointer data);
* |brief opens a window to start the game between two AIs
* |return nothing
**/
void update_gui_turn(GtkWidget *widget, gpointer p_tour);
/**
* |fn update_gui_turn(GtkWidget *widget, gpointer p_tour)
* |brief swithches turns between players
* |return nothing
**/
void wrapper_for_callback(GtkWidget *widget, gpointer data);
/**
* |fn wrapper_for_callback(GtkWidget *widget, gpointer data)
* |brief makes ties between action on the board the system 
* |return an opened window
**/




#endif
