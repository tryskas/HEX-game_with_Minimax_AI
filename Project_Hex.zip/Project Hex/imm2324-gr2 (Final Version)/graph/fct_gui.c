#ifndef FCT_GUI_C
#define FCT_GUI_C

#include "globals_gui.h"
#include "header_gui.h"

int tour = 1;
char game_info_label_text[30] = {'T', 'o', 'u', 'r', ' ', '1', '\0'};
GObject *game_grid;
GObject *game_info_label;
// input des actions des joueurs
GObject *p1_entry_send_button;
GObject *p2_entry_send_button;
GtkEntryBuffer *p1_entry_buffer;
GtkEntryBuffer *p2_entry_buffer;
GtkWidget *gui_cell_array[SIZE_TAB_GUI * SIZE_TAB_GUI]; // liste des boutons en 1 dimension, voir map_2d_to_1d
int dx[4] = {-1, 1, 1, -1};
int dy[4] = {-1, -1, 1, 1};
int mode_ia = 0;
int game_board[SIZE][SIZE] = {{0}};
int flag_ai_needs_to_start;

int readIntegerFromFile(const char *filename)
{
    FILE *file = fopen(filename, "r");

    if (file == NULL)
    {
        perror("Error opening file");
        return -1;
    }

    int value;

    if (fscanf(file, "%d", &value) != 1)
    {
        fclose(file);
        return -1;
    }

    fclose(file);
    return value;
}

int calculer_premiere_action()
{
    return (rand() % 36) + 1;
}

static void activate(GtkApplication *app, gpointer user_data)
{
    // initialisation variables
    GtkBuilder *builder_object = gtk_builder_new();
    p1_entry_buffer = gtk_entry_buffer_new(NULL, -1);
    p2_entry_buffer = gtk_entry_buffer_new(NULL, -1);
    // lecture du fichier ui
    gtk_builder_add_from_file(builder_object, "main.ui", NULL);
    gtk_builder_add_from_file(builder_object, "home.ui", NULL);
    // recuperation des objects dans variables

    // fenetre du jeu
    GtkWidget *main_window = GTK_WIDGET(gtk_builder_get_object(builder_object, "main_window"));
    GtkWidget *home_window = GTK_WIDGET(gtk_builder_get_object(builder_object, "home_window"));
    // grille générale
    GObject *main_grid = gtk_builder_get_object(builder_object, "main_grid");
    // grille des cases du jeu
    game_grid = gtk_builder_get_object(builder_object, "game_grid");
    // nom des jouers
    GObject *p1_label = gtk_builder_get_object(builder_object, "p1_label");
    GObject *p2_label = gtk_builder_get_object(builder_object, "p2_label");
    // input des actions des joueurs
    GObject *p1_entry = gtk_builder_get_object(builder_object, "p1_entry");
    GObject *p2_entry = gtk_builder_get_object(builder_object, "p2_entry");
    // ajout des buffer aux entry
    gtk_entry_set_buffer(GTK_ENTRY(p1_entry), p1_entry_buffer);
    gtk_entry_set_buffer(GTK_ENTRY(p2_entry), p2_entry_buffer);
    // limite les inputs a 2 characteres
    gtk_entry_set_max_length(GTK_ENTRY(p1_entry), 2);
    gtk_entry_set_max_length(GTK_ENTRY(p2_entry), 2);
    // boutons envoyer des inputs
    p1_entry_send_button = gtk_builder_get_object(builder_object, "p1_entry_send_button");
    p2_entry_send_button = gtk_builder_get_object(builder_object, "p2_entry_send_button");
    // en supposant que joueur 1 qui debute, on bloque initiallement le bouton du j2
    gtk_widget_set_sensitive(GTK_WIDGET(p2_entry_send_button), false);
    // autres boutons
    GObject *button_quit_main = gtk_builder_get_object(builder_object, "button_quit_main");
    GObject *button_quit_home = gtk_builder_get_object(builder_object, "button_quit_home");
    GObject *rules_button = gtk_builder_get_object(builder_object, "rules_button");
    GObject *button_home = gtk_builder_get_object(builder_object, "home_button");
    GObject *button_local_jcj = gtk_builder_get_object(builder_object, "button_local_jcj");
    GObject *button_local_ia = gtk_builder_get_object(builder_object, "button_local_ia");
    GObject *button_ia_special = gtk_builder_get_object(builder_object, "button_ia_special");
    // tour atteint
    game_info_label = gtk_builder_get_object(builder_object, "game_info_label");
    gtk_label_set_text(GTK_LABEL(game_info_label), game_info_label_text);

    // associer la fenetre à l'application
    gtk_window_set_application(GTK_WINDOW(main_window), app);
    gtk_window_set_application(GTK_WINDOW(home_window), app);
    // afficher fenetre
    gtk_window_set_title(GTK_WINDOW(main_window), "HEX");

    // normalisation taille des cases de jeu
    gtk_grid_set_column_homogeneous(GTK_GRID(game_grid), true);
    gtk_grid_set_row_homogeneous(GTK_GRID(game_grid), true);

    for (int row = 1; row < SIZE_TAB_GUI; row++) // on débute par 1 car 1ere ligne contient les labels
    {
        for (int col = 1; col < SIZE_TAB_GUI; col++) // on débute par 1 car 1ere colonne contient les labels
        {
            // char idx[11] = {}; // debug
            int i = map_2d_to_1d(row, col);
            // printf("case (%c%d)-> %d créee\n", row + 64, col - 1, i); // +64 et -1 car debute par 1 pas 0
            gui_cell_array[i] = gtk_button_new();
            // propriétés des boutons
            gtk_widget_set_vexpand(gui_cell_array[i], false);
            gtk_widget_set_hexpand(gui_cell_array[i], false);
            // enlever arriere plan
            gtk_button_set_has_frame(GTK_BUTTON(gui_cell_array[i]), false);
            // initialisation case vide
            gtk_button_set_child(GTK_BUTTON(gui_cell_array[i]), gtk_image_new_from_file(PATH_EMPTY_CELL));

            g_signal_connect(gui_cell_array[i], "clicked", G_CALLBACK(wrapper_for_callback), NULL);
            // ajout du bouton à la grille
            gtk_grid_attach(GTK_GRID(game_grid), gui_cell_array[i], col, row, 1, 1);
        }
    }

    GtkWidget *label1, *label2, *label3, *label4, *label5, *label6, *l1, *l2, *l3, *l4, *l5, *l6;
    label1 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label1), "<span foreground=\"#0000FF\">1</span>");
    label2 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label2), "<span foreground=\"#0000FF\">2</span>");
    label3 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label3), "<span foreground=\"#0000FF\">3</span>");
    label4 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label4), "<span foreground=\"#0000FF\">4</span>");
    label5 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label5), "<span foreground=\"#0000FF\">5</span>");
    label6 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label6), "<span foreground=\"#0000FF\">6</span>");
    l1 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(l1), "<span foreground=\"#FF0000\">A</span>");
    l2 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(l2), "<span foreground=\"#FF0000\">B</span>");
    l3 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(l3), "<span foreground=\"#FF0000\">C</span>");
    l4 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(l4), "<span foreground=\"#FF0000\">D</span>");
    l5 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(l5), "<span foreground=\"#FF0000\">E</span>");
    l6 = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(l6), "<span foreground=\"#FF0000\">F</span>");

    // Ajoutez les labels à la grille
    gtk_grid_attach(GTK_GRID(game_grid), label1, 7, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), label2, 7, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), label3, 7, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), label4, 7, 4, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), label5, 7, 5, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), label6, 7, 6, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), l1, 1, 7, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), l2, 2, 7, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), l3, 3, 7, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), l4, 4, 7, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), l5, 5, 7, 1, 1);
    gtk_grid_attach(GTK_GRID(game_grid), l6, 6, 7, 1, 1);

    // open home window
    gtk_widget_show(GTK_WIDGET(home_window));
    // open main window
    g_signal_connect(button_local_jcj, "clicked", G_CALLBACK(open_window_local_jcj), main_window);
    g_signal_connect(button_local_ia, "clicked", G_CALLBACK(open_window_local_ia), main_window);
    g_signal_connect(button_ia_special, "clicked", G_CALLBACK(open_window_special_ia), main_window);
    // callbacks des inputs textes
    g_signal_connect(p1_entry_send_button, "clicked", G_CALLBACK(callback_entry_p1), NULL);
    g_signal_connect(p2_entry_send_button, "clicked", G_CALLBACK(callback_entry_p2), NULL);
    // boutton quit
    g_signal_connect(button_quit_main, "clicked", G_CALLBACK(quit_application), app); // ne pas toucher car ca la grille ne se cree plus au cas ou ca change
    g_signal_connect(button_quit_home, "clicked", G_CALLBACK(quit_application), app);

    if (flag_ai_needs_to_start)
    {
        int first_move = calculer_premiere_action();
        struct ResultatValable struct_first_move = {0, map_1d_to_row(first_move), map_1d_to_col(first_move)};
        controleur_jeu(&struct_first_move);
        gtk_widget_set_sensitive(GTK_WIDGET(button_local_jcj), false);
    }
}

void victoire_nul_update_label(int flag_win) // flag win = 1 si victoire j1, 2 si victoire j2, 0 si match nul
{
    // changer label du texte
    if (flag_win)
    {
        sprintf(game_info_label_text, "Joueur %d a gagné", flag_win);
    }
    else
    {
        sprintf(game_info_label_text, "Match nul !");
    }
    gtk_label_set_text(GTK_LABEL(game_info_label), game_info_label_text);
    // desactiver boutons et entries
    gtk_widget_set_sensitive(GTK_WIDGET(p1_entry_send_button), false);
    gtk_widget_set_sensitive(GTK_WIDGET(p2_entry_send_button), false);
    for (int row = 1; row < SIZE_TAB_GUI; row++) // on débute par 1 car 1ere ligne contient les labels
    {
        for (int col = 1; col < SIZE_TAB_GUI; col++) // on débute par 1 car 1ere colonne contient les labels
        {
            // char idx[11] = {}; // debug
            int i = map_2d_to_1d(row, col);
            gtk_widget_set_sensitive(GTK_WIDGET(gui_cell_array[i]), false);
        }
    }
}

// Function to calculate the average distance to the edges of the board
int calculateAverageDistanceToEdges(int game_board[][SIZE], int player)
{
    int totalDistance = 0;
    int numPieces = 0;

    for (int line = 0; line < SIZE; line++)
    {
        for (int column = 0; column < SIZE; column++)
        {
            if (game_board[line][column] == player)
            {
                int distance = MIN(line, SIZE - 1 - line) + MIN(column, SIZE - 1 - column);
                totalDistance += distance;
                numPieces++;
            }
        }
    }

    // Avaid getting a division by zero
    if (numPieces == 0)
    {
        return 0;
    }

    // Calculate the average distance to the edges of the board
    int avgDistance = totalDistance / numPieces;
    return avgDistance;
}
// Function to determine the best move available for the AI
int evaluate(int game_board[][SIZE], int player, int isClient)
{
    if (verifyVictory(game_board, player) == 1)
    {
        if (isClient)
        {
            if (player == 1)
            {
                return INT_MAX;
            }
            else
            {
                return INT_MIN;
            }
        }
        else
        {
            if (player == 2)
            {
                return INT_MAX;
            }
            else
            {
                return INT_MIN;
            }
        }
    }

    int score = 0;

    if (isClient)
    {
        if (game_board[centerX][centerY] == 2)
        {
            score += 20;
        }
        else if (game_board[centerX][centerY] == 1)
        {
            score -= 20;
        }
    }
    else
    {
        if (game_board[centerX][centerY] == 1)
        {
            score += 20;
        }
        else if (game_board[centerX][centerY] == 2)
        {
            score -= 20;
        }
    }

    // Search for patterns of aligned filled squares by players in diagonal
    for (int line = 0; line < SIZE; line++)
    {
        for (int column = 0; column < SIZE; column++)
        {
            if (game_board[line][column] == player)
            {

                for (int direction = 0; direction < 4; direction++)
                {
                    int count = 1; // Number of aligned pieces
                    int x = line + dx[direction];
                    int y = column + dy[direction];

                    while (isValidPosition(x, y) && game_board[x][y] == player)
                    {
                        count++;
                        x += dx[direction];
                        y += dy[direction];
                    }

                    // Attribution of scores depending on the number of aligned pieces
                    if (count >= 3)
                    {

                        if (isClient)
                        {
                            if (player == 1)
                            {

                                score += 100; // Example : player 2 has a pattern of 3 pieces aligned in diagonal
                            }
                            else
                            {
                                score -= 100; // Example : player 1 has a pattern of 3 pieces aligned in diagonal
                            }
                        }
                        else
                        {
                            if (player == 2)
                            {

                                score += 100; // Example : player 2 has a pattern of 3 pieces aligned in diagonal
                            }
                            else
                            {
                                score -= 100; // Example : player 1 has a pattern of 3 pieces aligned in diagonal
                            }
                        }
                    }

                    if (count == 2)
                    {
                        if (isClient)
                        {
                            if (player == 1)
                            {
                                score += 50; // Player 2 can possibly block player 1
                            }
                            else
                            {
                                score -= 50; // Player 1 can possibly block player 2
                            }
                        }
                        else
                        {
                            if (player == 2)
                            {
                                score += 50; // Player 1 can possibly block player 2
                            }
                            else
                            {
                                score -= 50; // Player 2 can possibly block player 1
                            }
                        }
                    }
                }
            }
        }
    }

    // Detection of the possibility to block the opponent
    if (isClient)
    {
        int opponent = (player == 1) ? 2 : 1;

        // Browse the board to verify if the opponent can win in the next turn
        for (int line = 0; line < SIZE; line++)
        {
            for (int column = 0; column < SIZE; column++)
            {
                if (game_board[line][column] == 0)
                {
                    // Empty square, try to simulate the movement of the opponent
                    game_board[line][column] = opponent;

                    // Verify if the opponent can win after the simulated movement
                    if (verifyVictory(game_board, opponent) == 1)
                    {
                        // The opponent can win in the next turn if it's not blocked
                        // You can assign a penalty here, for example :
                        score += 100;
                    }

                    // Cancel the simulated movement
                    game_board[line][column] = 0;
                }
            }
        }
    }

    // Stores into a variable the score of the empty squares (the closer they are from the center the more they give points)
    // Allow the AI to prioritize to a certain extent the take of the squares in the middle of the board
    int proximityScore = calculateAverageDistanceToEdges(game_board, player);
    if (isClient)
    {
        if (player == 1)
        {
            score += proximityScore;
        }
        else
        {
            score -= proximityScore;
        }
    }
    else
    {
        if (player == 2)
        {
            score += proximityScore;
        }
        else
        {
            score -= proximityScore;
        }
    }

    return score;
}

SearchResult alphabeta(int game_board[][SIZE], int depth, int player, int alpha, int beta, int isClient)
{
    SearchResult result;

    // If the server executes this program : the AI is the player 2
    // Otherwise the client executes the program and the AI is the player 1
    if (isClient)
    {
        result.value = (player == 1) ? INT_MIN : INT_MAX;
    }

    else
    {
        result.value = (player == 2) ? INT_MIN : INT_MAX;
    }

    Move bestMove;
    bestMove.line = -1;
    bestMove.column = -1;

    // Basic situation : if the depth is null or if there is a victory
    if (depth == 0 || verifyVictory(game_board, player) == 1)
    {
        result.value = evaluate(game_board, player, isClient);
        return result;
    }

    for (int line = 0; line < SIZE; line++)
    {
        for (int column = 0; column < SIZE; column++)
        {
            if (game_board[line][column] == 0)
            {
                // Make the hypothetical movement of the player to simulate
                game_board[line][column] = player;

                // Recursive call of the function to evaluate the movement
                SearchResult moveResult = alphabeta(game_board, depth - 1, (player == 1) ? 2 : 1, alpha, beta, isClient);

                // Cancel the hypothetical movement
                game_board[line][column] = 0;

                // Update the best movement if necessary
                if (isClient)
                {
                    if (player == 1)
                    {
                        if (moveResult.value > result.value)
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        alpha = (alpha > result.value) ? alpha : result.value;
                        if (beta <= alpha)
                        {
                            result.move = bestMove;
                            return result; // Beta Pruning
                        }
                    }
                    else
                    {
                        if (moveResult.value < result.value)
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        beta = (beta < result.value) ? beta : result.value;
                        if (beta <= alpha)
                        {
                            result.move = bestMove;
                            return result; // Alpha Pruning
                        }
                    }
                }
                else
                {
                    if (player == 2)
                    {
                        if (moveResult.value > result.value)
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        alpha = (alpha > result.value) ? alpha : result.value;
                        if (beta <= alpha)
                        {
                            result.move = bestMove;
                            return result; // Beta Pruning
                        }
                    }
                    else
                    {
                        if (moveResult.value < result.value)
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        beta = (beta < result.value) ? beta : result.value;
                        if (beta <= alpha)
                        {
                            result.move = bestMove;
                            return result; // Alpha Pruning
                        }
                    }
                }
            }
        }
    }

    // If the best position is still the default value (-1, -1)
    // Choose a valid position by default (the first in the array/board by beginning at the top left)
    if (bestMove.line == -1 && bestMove.column == -1)
    {
        for (int line = 0; line < SIZE; line++)
        {
            for (int column = 0; column < SIZE; column++)
            {
                if (game_board[line][column] == 0)
                {
                    bestMove.line = line;
                    bestMove.column = column;
                    break;
                }
            }
            if (bestMove.line != -1 && bestMove.column != -1)
            {
                break;
            }
        }
    }

    result.move = bestMove;
    return result;
}

static void callback_entry_p1(GtkWidget *bouton_entry_p1, gpointer user_data)
{
    // faut executer l'action envoyée
    char text_entry[5];
    // get text from entry
    strcpy(text_entry, gtk_entry_buffer_get_text(p1_entry_buffer));
    int l = text_entry[1] - '0';
    int col = (int)tolower(text_entry[0]) - 97;
    struct ResultatValable action_entry = {0, col, l - 1};
    controleur_jeu(&action_entry);
}

static void callback_entry_p2(GtkWidget *bouton_entry_p2, gpointer user_data)
{
    // faut executer l'action envoyée
    char text_entry[5];
    // get text from entry
    strcpy(text_entry, gtk_entry_buffer_get_text(p2_entry_buffer));
    int l = text_entry[1] - '0';
    int col = (int)tolower(text_entry[0]) - 97;
    struct ResultatValable action_entry = {0, col, l - 1};
    controleur_jeu(&action_entry);
}

void valable_struct(struct ResultatValable *action, int tableau[][SIZE])
{
    action->valid = 0;
    if (action->line >= 0 && action->line <= 6 && action->column >= 0 && action->column <= 6)
    {
        int casetableau = tableau[action->line][action->column];
        if (casetableau == 0)
        { // la case est vide donc on peut faire des trucs
            action->valid = 1;
        }
    }
    // printf("resultat = %d %d %d \n",resultat.valide,resultat.coord.colonne,resultat.coord.ligne);
    // si invalide, on retourne struct avec valide=0
}

int map_2d_to_1d(int row, int col)
{
    // definit l'ordre du tableau 1 dim; indexes should be 1-6
    return ((row - 1) * 6) + col - 1; // -1 sur row et col car ils debutent par 1 (0 contient les labels)
}

void int2Char(int d, char buffer[3])
{ // traite d jusqu a 99, en base 10
    if (d >= 0 && d <= 9)
    {
        buffer[0] = (char)(d + '0');
        buffer[1] = '\0';
    }
    else if (d >= 10 && d <= 99)
    {
        buffer[0] = (char)(d / 10 + '0');
        buffer[1] = (char)(d % 10 + '0');
        buffer[2] = '\0';
    }
    else
    {
        printf("conversion int a string echouee!!!");
    }
}

void update_turn_label()
{
    char temp[3];
    int2Char(tour, temp);
    game_info_label_text[5] = '\0'; // removing the current number
    strcat(game_info_label_text, temp);
    gtk_label_set_text(GTK_LABEL(game_info_label), game_info_label_text);
}

void print_hello(GtkWidget *widget, gpointer data)
{
    g_print("Hello World\n");
}

void quit_application(GtkWidget *widget, gpointer gp_app)
{ // pour debugging
    GApplication *app = G_APPLICATION(gp_app);
    g_application_quit(app);
}

static void open_window_local_jcj(GtkWidget *widget, gpointer data)
{
    mode_ia = 0;
    GtkWidget *window = GTK_WIDGET(data);
    gtk_widget_show(window);
}

static void open_window_local_ia(GtkWidget *widget, gpointer data)
{
    mode_ia = 1;
    GtkWidget *window = GTK_WIDGET(data);
    gtk_widget_show(window);
}

static void open_window_special_ia(GtkWidget *widget, gpointer data)
{
    mode_ia = 2;
    GtkWidget *window = GTK_WIDGET(data);
    gtk_widget_show(window);
}

void update_gui_turn(GtkWidget *widget, gpointer p_tour) // p_tour est l'addresse de la variable gloable tour
{
    // utilise le nbre de tour atteint pour savoir qui a joué j1 ou j2
    int tour = *(int *)p_tour;
    int a_qui_le_tour_inverse = (tour % 2) + 1; // attention inversé 2 pour j1, 1 pour j2, qui a juste joué
    switch (a_qui_le_tour_inverse)
    {
    case 2: // case remplie joueur 1 (impair)
        // printf("j1 colored;)\n");
        gtk_button_set_child(GTK_BUTTON(widget), gtk_image_new_from_file(PATH_P1_CELL));
        // faut desactiver bouton du joueur 1 et activer l'autre
        gtk_widget_set_sensitive(GTK_WIDGET(p1_entry_send_button), false);
        gtk_widget_set_sensitive(GTK_WIDGET(p2_entry_send_button), true);
        break;
    case 1: // case remplie joueur 2(pair)
        // printf("j2 colored;)\n");
        gtk_button_set_child(GTK_BUTTON(widget), gtk_image_new_from_file(PATH_P2_CELL));
        // faut desactiver bouton du joueur 2 et activer l'autre
        gtk_widget_set_sensitive(GTK_WIDGET(p2_entry_send_button), false);
        gtk_widget_set_sensitive(GTK_WIDGET(p1_entry_send_button), true);
        break;
    default: // case vide
        gtk_button_set_child(GTK_BUTTON(widget), gtk_image_new_from_file(PATH_EMPTY_CELL));
        break;
    }

    //(*(int *)p_tour)++; // bof
    gtk_widget_set_sensitive(widget, false);
    update_turn_label();
}

int editgame_board(int index_letter1, int index_letter2, int turn)
{ // lettre1 = colonne
    int val = 0;
    if (tour % 2 == 0)
    {
        val = 2;
    }
    else
    {
        val = 1;
    }
    game_board[index_letter2][index_letter1] = val;
    return game_board[SIZE][SIZE];
}

int controleur_jeu(struct ResultatValable *p_prompt)
{
    printf("coup recu: %d,%d \n", p_prompt->line, p_prompt->column);
    /*
     cette fct peut etre appellee uniquement par le joueur, elle
        verifie si coup valide:
            -si oui
                - elle bloque l'input du joueur qui a juste joué et debloque l'autre pour prochain tour
                - modifie tableau backend et colorie bouton et si mode_reso envoie l'action
            -sinon elle ne bloque rien et laisse
    */

    if (sizeof(p_prompt) == 0)
    { // prompt invalide, afficher message d'erreur
        printf("prompt invalide!!!!");
    }
    else
    {
        valable_struct(p_prompt, game_board);
        struct ResultatValable resultat = {p_prompt->valid, p_prompt->column, p_prompt->line};
        // printf("\nhey its valid %d;)\n", resultat.valid);
        if (resultat.valid == 1)
        {
            // printf("Coup valable en %d %d\n",resultat.coord.colonne,resultat.coord.ligne);
            //  modification tableau backend
            game_board[SIZE][SIZE] = editgame_board(resultat.column, resultat.line, tour);
            // modification graphique
            GtkGrid *cast_grid = GTK_GRID(game_grid);
            update_gui_turn(gtk_grid_get_child_at(cast_grid, resultat.column + 1, resultat.line + 1), &tour);
            tour++; // on incremente le tour
            flag_ai_needs_to_start = 0;
            if (mode_ia == 1 && flag_ai_needs_to_start == 0)
            {                                                                                            // j c ia, demande action a ia et la declenche
                SearchResult action_calculee = alphabeta(game_board, DEPTH_MAX, 2, INT_MIN, INT_MAX, 1); // 2 car ia joue toujours en modee j2

                //  modification tableau backend
                game_board[SIZE][SIZE] = editgame_board(action_calculee.move.column, action_calculee.move.line, tour);
                // modification graphique
                update_gui_turn(gtk_grid_get_child_at(cast_grid, action_calculee.move.column + 1, action_calculee.move.line + 1), &tour);
                printf("ai has played: %d,%d\n", action_calculee.move.line, action_calculee.move.column);
                tour++; // on incremente le tour
            }
            else if (mode_ia == 2)
            {                            // local ia v ia
                int joueur_qui_joue = 2; // à alterner entre 1 et 2, 2 car on debute par 1 manuellemnt
                while (!(verifyVictory(game_board, 1) || verifyVictory(game_board, 2)))
                {
                    SearchResult action_calculee = alphabeta(game_board, DEPTH_MAX, joueur_qui_joue, INT_MIN, INT_MAX, 1); // 2 car ia joue toujours en modee j2

                    //  modification tableau backend
                    game_board[SIZE][SIZE] = editgame_board(action_calculee.move.column, action_calculee.move.line, tour);
                    // modification graphique
                    update_gui_turn(gtk_grid_get_child_at(cast_grid, action_calculee.move.column + 1, action_calculee.move.line + 1), &tour);
                    printf("ai has played: %d,%d\n", action_calculee.move.line, action_calculee.move.column);
                    joueur_qui_joue = 3 - joueur_qui_joue;
                    tour++; // on incremente le tour
                    if (tour == 37)
                        break;
                }
            }
            int win_j1 = verifyVictory(game_board, 1);
            int win_j2 = verifyVictory(game_board, 2);
            if (win_j1)
            {
                victoire_nul_update_label(1); // j1 gagné
            }
            else if (win_j2)
            {
                victoire_nul_update_label(2); // j2 gagné
            }
            else if (tour == 37)
            {
                victoire_nul_update_label(0); // matche nul
            }
        }
        else
        {
            // warning gtk
            // printf("Coup pas valable en %d %d\n", resultat.column, resultat.line);
            g_print("Coup pas valable :%d en %d %d\n", resultat.valid, resultat.column, resultat.line);
        }
    }
}

int get_pos_widget_in_array(GtkWidget *widget, GtkWidget **grid, int grid_size)
{ // retourne position d'un widget dans une liste de widgets, si ne retrouve pas retourne -1
    int i = 0;
    while (i < grid_size)
    {
        if (*(grid + i) == widget)
            return i;
        i++;
    }
    return -1;
}

// attention tableau gui contient 49 cases
//  ces 2 fcts retourneront indices des lignes et col dans grille 6x6, si on veut pour 7x7, ajouter +1 aux retruns
int map_1d_to_row(int idx)
{ // returns row of result of mapping 1d to 2d coordinates
    return (idx / 6);
}

int map_1d_to_col(int idx)
{ // returns row of result of mapping 1d to 2d coordinates
    return (idx % 6);
}

void wrapper_for_callback(GtkWidget *widget, gpointer data)
{
    // on extrait le bouton du prompt
    int pos_1d = get_pos_widget_in_array(widget, gui_cell_array, SIZE_TAB_GUI * SIZE_TAB_GUI);
    int col_arg = map_1d_to_col(pos_1d);
    int line_arg = map_1d_to_row(pos_1d);
    struct ResultatValable temp = {1, col_arg, line_arg};
    controleur_jeu(&temp);
}
// fcts internes a celle de verif victoire

int sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6])
{
    if (!isValidPosition(x, y))
    {
        return 0;
    }

    visited[x][y] = 1;

    if ((player == 1 && y == 5) || (player == 2 && x == 5))
    {
        return 1;
    }

    for (int yCoo = y - 1; yCoo <= y + 1; yCoo++)
    {
        for (int xCoo = x - 1; xCoo <= x + 1; xCoo++)
        {
            if (xCoo != x && yCoo != y)
            {
                if (tab[xCoo][yCoo] == player && visited[xCoo][yCoo] == 0)
                {
                    if (sideConnected(tab, xCoo, yCoo, player, visited) == 1)
                    {
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

int isValidPosition(int x, int y)
{
    return (x >= 0 && x < SIZE && y >= 0 && y < SIZE);
}

// utilise le principe de recherhce en profondeur
int verifyVictory(int tab[][SIZE], int player)
{
    int visited[SIZE][SIZE] = {{0}};

    if (player == 2)
    {
        for (int j = 0; j < SIZE; j++)
        {
            if ((tab[0][j] == player) && (sideConnected(tab, 0, j, player, visited) == 1))
            {
                return 1;
            }
        }
        return 0;
    }
    else
    {
        for (int j = 0; j < SIZE; j++)
        {
            if ((tab[j][0] == player) && (sideConnected(tab, j, 0, player, visited) == 1))
            {
                return 1;
            }
        }
        return 0;
    }
}

#endif
