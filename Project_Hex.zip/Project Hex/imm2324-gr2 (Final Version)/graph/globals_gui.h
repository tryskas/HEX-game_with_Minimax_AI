#ifndef GLOBALS_GUI_H
#define GLOBALS_GUI_H

#include <gtk/gtk.h>

#define PATH_EMPTY_CELL "imgs/grey.png"
#define PATH_P1_CELL "imgs/blue.png"
#define PATH_P2_CELL "imgs/red.png"
#define SIZE_TAB_GUI 7 // 7 car faut ajouter les labels
#define SIZE 6
#define DEPTH_MAX 5

#define centerX SIZE/2
#define centerY SIZE/2




extern int tour;
extern char game_info_label_text[30];
extern GObject *game_info_label;
extern GObject *game_grid;
extern GObject *p1_entry_send_button;
extern GObject *p2_entry_send_button;
extern GtkEntryBuffer *p1_entry_buffer;
extern GtkEntryBuffer *p2_entry_buffer;
extern GtkWidget *gui_cell_array[SIZE_TAB_GUI * SIZE_TAB_GUI]; // liste des boutons en 1 dimension, voir map_2d_to_1d
extern int dx[4];
extern int dy[4];
extern int mode_ia;
/*
    0 pour JcJ
    1 pour JcIA
    2 pour IAcIA
*/





#endif
