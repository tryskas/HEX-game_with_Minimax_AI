/**
* \file header_gui.h
* \brief Declares function and structures of all the files of the gtk program
*
*
*/
#ifndef HEADER_GUI_H
#define HEADER_GUI_H

#include "globals_gui.h"

/**
* \struct move header_gui.h fct_gui.c
* \brief Structure to to store the line and column of a move
*/
typedef struct
{
    int line;
    int column;
}Move;

/**
* \struct SearchResult header_gui.h fct_gui.c
* \brief Structure to store the value of the function SearchResult
*/
typedef struct
{
    int value;
    Move move;
} SearchResult;

/**
* \struct ResultatValable header_gui.h fct_gui.c
* \brief Structure to store the result of the validity test
*/
struct ResultatValable {
    int valid;
    int column;
    int line;
};



// partie jeu

/**
* \fn calculer_premiere_action()
* \brief randomly chooses the first action of the game
* \return number of the action
*/
int calculer_premiere_action();

/**
* \fn calculateAverageDistanceToEdges()
* \brief calculate the average distance to the edges of the board
* \param game_board he game board in 2D of 6 squares by 6 squares
* \param player indicates if it's for player 1 or 2
* \return Returns the distance to the edge
*/
int calculateAverageDistanceToEdges(int game_board[][SIZE], int player);

/**
* \fn evaluate()
* \brief Function to determine the best move available for the AI
* \param game_board he game board in 2D of 6 squares by 6 squares
* \param player indicates if it's for player 1 or 2
* \param isClient indicates if we are the client or the host
* \return the best move
*/
int evaluate (int game_board[][SIZE], int player, int isClient);
SearchResult alphabeta(int game_board[][SIZE], int depth, int player, int alpha, int beta, int isClient);

/**
* \fn valable_struct()
* \brief determines if we can play on that square
* \param tableau array of 1 dimension
* \return nothing
*/
void valable_struct(struct ResultatValable *action, int tableau[][SIZE]);

/**
* \fn editgame_board()
* \brief modifies the gameboard depending on the move played
* \param index_letter1 number of the column
* \param index_letter2 number of the row
* \param turn number of the turn
* \return the new 2D gameboard
*/
int editgame_board(int index_letter1, int index_letter2, int turn);

/**
* \fn controleur_jeu()
* \brief verifies if the move is valid
* \return the new backend array if the move is valid
*/
int controleur_jeu(struct ResultatValable *p_prompt);

/**
* \fn sideConnected()
* \brief verfies if the two sides of the gameboard are connected
* \param visited[6][6] 6x6 array of already vivisted squares
* \param x horizontal position
* \param y vertical position
* \return the new backend array if the move is valid
*/
int sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited[6][6]);

/**
* \fn isValidPosition()
* \brief verifies if the entered vertical and hoorizontal positions make a valid position on the grid
* \param x horizontal position
* \param y vertical position
* \return FALSE if no, TRUE if yes
*/
int isValidPosition(int x, int y);

/**
* \fn VerifyVictory()
* \brief uses the sideConnect fonction to verifie if the choosen player won
* \param player one or two
* \return 1 if the player won, 0 if he didn't
*/
int verifyVictory(int tab[][SIZE], int player);


// utilitaires tableaux et autres

/**
* \fn readIntegerFromFile()
* \brief reads the needed integer from the targeted file
* \returns 1 if the player won, 0 if he didn't
*/
int readIntegerFromFile(const char *filename);

/**
* \fn map_2d_to_1d()
* \brief transforms a 2D array to a 1D array
* \param row index of the row
* \param col index of the column
* \returns 1D array
*/
int map_2d_to_1d(int row, int col);

/**
* \fn int2char()
* \brief converts an integer into a string
* \returns nothing
*/
void int2Char(int d, char buffer[3]);

/**
* \fn map_1d_to_row()
* \brief Function to convert mapping from 1D to 2D on the rows
* \param idx index of the row in 2D
* \return Returns row of result of mapping 1d to 2d coordinates
*/
int map_1d_to_row(int idx);

/**
* \fn map_1d_to_col()
* \brief Function to convert mapping from 1D to 2D on the columns
* \param idx index of the column in 2D
* \return Returns row of result of mapping 1d to 2d coordinates
*/
int map_1d_to_col(int idx);

/**
* \fn get_pos_widget_in_array()
* \brief caalculates the position of a widget in a list of widgets
* \param grid_size size of the grid
* \param GtkWidget *widget pointer to a gtkwidget
* \param GtkWidget **grid pointer to aa gtkGrid
* \return the position of  a widget or -1 if it isn't there
*/
int get_pos_widget_in_array(GtkWidget *widget, GtkWidget **grid, int grid_size);


// gtk 

/**
* \fn activate()
* \brief fonction activation des widgets
* \param GtkApplication *app pointer to an app widget
* \return nothing
*/
static void activate(GtkApplication *app, gpointer user_data);

/**
* \fn victoire_nul_update_label()
* \brief update etat du jeu
* \param flag_win 1 if p1 won, 2 if p2 won, 0 if null
* \return  nothing
*/
void victoire_nul_update_label(int flag_win);
/**
* |fn callback_entry_pt1(GtkWidget *bouton_entry_p1, gpointer user_data)
* |brief makes a precised move of the player 1 on the board
* |return nothing
**/
static void callback_entry_p1(GtkWidget *bouton_entry_p1, gpointer user_data);
/**
* |fn callback_entry_pt2(GtkWidget *bouton_entry_p2, gpointer user_data)
* |brief makes a precised move of the player 2 on the board
* |return nothing
**/
static void callback_entry_p2(GtkWidget *bouton_entry_p2, gpointer user_data);
/**
* |fn update_turn_label()
* |brief changes the number of the player who has to make a move everytime the other player does 
* |return nothing
**/
void update_turn_label();

void print_hello(GtkWidget *widget, gpointer data);
void quit_application(GtkWidget *widget, gpointer gp_app);
/**
* |fn open_window_local_jcj(GtkWidget *widget, gpointer data)
* |brief opens a window to start the game between two players 
* |return nothing
**/
static void open_window_local_jcj(GtkWidget *widget, gpointer data);
/**
* |fn open_window_local_ia(GtkWidget *widget, gpointer data)
* |brief opens a window to start the game between a human player and AI 
* |return nothing
**/
static void open_window_local_ia(GtkWidget *widget, gpointer data);

/**
* |fn open_window_special_ia(GtkWidget *widget, gpointer data);
* |brief opens a window to start the game between two AIs
* |return nothing
**/
static void open_window_special_ia(GtkWidget *widget, gpointer data);

/**
* |fn update_gui_turn(GtkWidget *widget, gpointer p_tour)
* |brief swithches turns between players
* |return nothing
**/
void update_gui_turn(GtkWidget *widget, gpointer p_tour);
/**
* |fn wrapper_for_callback(GtkWidget *widget, gpointer data)
* |brief makes ties between action on the board the system 
* |return an opened window
**/

void wrapper_for_callback(GtkWidget *widget, gpointer data);



#endif
