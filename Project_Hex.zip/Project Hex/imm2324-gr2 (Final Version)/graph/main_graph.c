#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>


#include "fct_gui.c"


// pour effectuer changement sur grille, suffit de clicker sur le bouton en utilisant le code suivant
// g_signal_emit_by_name(button, "clicked");
// faire attention quand incrementer le tour, avant ou apres le click

// attention quand on ferme la game et on reouvre en utilisant le home window ca ne veut plus se fermer
// attention game_grid est la grille seulement
// gui_cell_array est tableau 1 dimension qui contient les 36 boutons
// tableau_jeu est le tableau backend contenant des int 




int main(int argc, char **argv)
{

    flag_ai_needs_to_start=readIntegerFromFile(".test");
    
    
    GtkApplication *app;
    int status;

    app = gtk_application_new("org.immersion.gr2", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
    status = g_application_run(G_APPLICATION(app), argc, argv);

    g_object_unref(app);

    return status;
}
