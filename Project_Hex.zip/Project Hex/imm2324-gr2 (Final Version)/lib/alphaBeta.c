/**
* \file alphaBeta.c
* \brief Creates the functions used to make the AI
*
*
*/

// Includes all the headers and libraries needed
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "const.h"

// Function to get the minimum of 2 values a & b
#define MIN(a, b) ((a) < (b) ? (a) : (b))

static int dx[] = {-1, 1, 1, -1};
static int dy[] = {-1, -1, 1, 1};


// Function to calculate the average distance to the edges of the board
int calculateAverageDistanceToEdges(int game_board[][SIZE], int player) {
    int totalDistance = 0;
    int numPieces = 0;

    for (int line = 0; line < SIZE; line++) {
        for (int column = 0; column < SIZE; column++) {
            if (game_board[line][column] == player) {
                int distance = MIN(line, SIZE - 1 - line) + MIN(column, SIZE - 1 - column);
                totalDistance += distance;
                numPieces++;
            }
        }
    }

    // Avaid getting a division by zero
    if (numPieces == 0) {
        return 0;
    }

    // Calculate the average distance to the edges of the board
    int avgDistance = totalDistance / numPieces;
    return avgDistance;
}

// Function to determine the best move available for the AI
int evaluate (int game_board[][SIZE], int player, int isClient)
{
    if (verifyVictory (game_board, player) == 1)
    {
        if (isClient)
        {
            if (player == 1)
            {
                return INT_MAX;
            }
            else
            {
                return INT_MIN;
            }   
        }
        else
        {
            if (player == 2)
            {
                return INT_MAX;
            }
            else
            {
                return INT_MIN;
            }   
        }
    }

    int score = 0;

    if (isClient)
    {  
        if (game_board[centerX][centerY] == 2)
        {
            score += 20;
        }
        else if (game_board[centerX][centerY] == 1)
        {
            score -= 20;
        }
    }
    else
    {
        if (game_board[centerX][centerY] == 1)
        {
            score += 20;
        }
        else if (game_board[centerX][centerY] == 2)
        {
            score -= 20;
        }
    }

    // Search for patterns of aligned filled squares by players in diagonal
    for (int line = 0; line < SIZE; line++) {
        for (int column = 0; column < SIZE; column++) {
            if (game_board[line][column] == player) {


                for (int direction = 0; direction < 4; direction++) {
                    int count = 1; // Number of aligned pieces
                    int x = line + dx[direction];
                    int y = column + dy[direction];

                    while (isValidPosition(x, y) && game_board[x][y] == player) {
                        count++;
                        x += dx[direction];
                        y += dy[direction];
                    }

                    // Attribution of scores depending on the number of aligned pieces
                    if (count >= 3) {

                        if (isClient)
                        {
                            if (player == 1) {

                                score += 100; // Example : player 2 has a pattern of 3 pieces aligned in diagonal
                            } else {
                                score -= 100; // Example : player 1 has a pattern of 3 pieces aligned in diagonal
                            }
                        }
                        else
                        {
                            if (player == 2) {

                                score += 100; // Example : player 2 has a pattern of 3 pieces aligned in diagonal
                            } else {
                                score -= 100; // Example : player 1 has a pattern of 3 pieces aligned in diagonal
                            }
                        }
                    }

                    if (count == 2) {
                        if (isClient)
                        {
                            if (player == 1) 
                            {
                                score += 50; // Player 2 can possibly block player 1
                            } else 
                            {
                                score -= 50; // Player 1 can possibly block player 2
                            }
                        }
                        else
                        {
                            if (player == 2) 
                            {
                                score += 50; // Player 1 can possibly block player 2
                            } else 
                            {
                                score -= 50; // Player 2 can possibly block player 1
                            }
                        }
                    }
                }
            }
        }
    }


    // Detection of the possibility to block the opponent
    if (isClient)
    {
        int opponent = (player == 1) ? 2 : 1;

        // Browse the board to verify if the opponent can win in the next turn
        for (int line = 0; line < SIZE; line++)
        {
            for (int column = 0; column < SIZE; column++)
            {
                if (game_board[line][column] == 0)
                {
                    // Empty square, try to simulate the movement of the opponent
                    game_board[line][column] = opponent;

                    // Verify if the opponent can win after the simulated movement
                    if (verifyVictory(game_board, opponent) == 1)
                    {
                        // The opponent can win in the next turn if it's not blocked
                        // You can assign a penalty here, for example :
                        score += 100;
                    }

                    // Cancel the simulated movement
                    game_board[line][column] = 0;
                }
            }
        }
    }

    // Stores into a variable the score of the empty squares (the closer they are from the center the more they give points)
    // Allow the AI to prioritize to a certain extent the take of the squares in the middle of the board
    int proximityScore = calculateAverageDistanceToEdges(game_board, player);
    if (isClient)
    {
        if (player == 1)
        {
            score += proximityScore;
        }
        else
        {
            score -= proximityScore;
        }
    }
    else
    {
        if (player == 2)
        {
            score += proximityScore;
        }
        else
        {
            score -= proximityScore;
        }
    }

    return score;
}


SearchResult alphabeta(int game_board[][SIZE], int depth, int player, int alpha, int beta, int isClient) {
    SearchResult result;
    
    // If the server executes this program : the AI is the player 2
    // Otherwise the client executes the program and the AI is the player 1
    if (isClient)
    {
        result.value = (player == 1) ? INT_MIN : INT_MAX;
    }

    else
    {
        result.value = (player == 2) ? INT_MIN : INT_MAX;
    }

    Move bestMove;
    bestMove.line = -1;
    bestMove.column = -1;

    // Basic situation : if the depth is null or if there is a victory
    if (depth == 0 || verifyVictory(game_board, player) == 1) {
        result.value = evaluate(game_board, player, isClient);
        return result;
    }




    for (int line = 0; line < SIZE; line++) {
        for (int column = 0; column < SIZE; column++) {
            if (game_board[line][column] == 0) {
                // Make the hypothetical movement of the player to simulate
                game_board[line][column] = player;

                // Recursive call of the function to evaluate the movement
                SearchResult moveResult = alphabeta(game_board, depth - 1, (player == 1) ? 2 : 1, alpha, beta, isClient);

                // Cancel the hypothetical movement
                game_board[line][column] = 0;

                // Update the best movement if necessary
                if (isClient)
                {
                    if (player == 1) 
                    {
                        if (moveResult.value > result.value) 
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        alpha = (alpha > result.value) ? alpha : result.value;
                        if (beta <= alpha) 
                        {
                            result.move = bestMove;
                            return result; // Beta Pruning
                        }
                    } 
                    else 
                    {
                        if (moveResult.value < result.value) 
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        beta = (beta < result.value) ? beta : result.value;
                        if (beta <= alpha) 
                        {
                            result.move = bestMove;
                            return result; // Alpha Pruning
                        }
                    }
                }
                else
                {
                    if (player == 2) 
                    {
                        if (moveResult.value > result.value) 
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        alpha = (alpha > result.value) ? alpha : result.value;
                        if (beta <= alpha) 
                        {
                            result.move = bestMove;
                            return result; // Beta Pruning
                        }
                    } 
                    else 
                    {
                        if (moveResult.value < result.value) 
                        {
                            result.value = moveResult.value;
                            bestMove.line = line;
                            bestMove.column = column;
                        }
                        beta = (beta < result.value) ? beta : result.value;
                        if (beta <= alpha) 
                        {
                            result.move = bestMove;
                            return result; // Alpha Pruning
                        }
                    }
                }
            }
        }
    }

    // If the best position is still the default value (-1, -1)
    // Choose a valid position by default (the first in the array/board by beginning at the top left) 
    if (bestMove.line == -1 && bestMove.column == -1) {
        for (int line = 0; line < SIZE; line++) {
            for (int column = 0; column < SIZE; column++) {
                if (game_board[line][column] == 0) {
                    bestMove.line = line;
                    bestMove.column = column;
                    break;
                }
            }
            if (bestMove.line != -1 && bestMove.column != -1) {
                break;
            }
        }
    }

    result.move = bestMove;
    return result;
}

