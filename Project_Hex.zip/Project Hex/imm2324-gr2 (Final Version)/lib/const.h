/**
* \file const.h
* \brief Defines the constants used in all the files of the program
*
*
*/

#ifndef CONST_H
#define CONST_H

// Define the center of the board in x and y (depends on the SIZE)
#define centerX SIZE/2
#define centerY SIZE/2

#define BUFFER_SIZE 1024 // Defines the size of the buffer (the message sent and received in the network functions)
#define MAX_CLIENTS 2 // Defines the number of clients able to connect to the server

#define SIZE 6 // Defines the size of 1 dimension of the board (length or width)

#define DEPTH_MAX 6 // Defines the size of the maximum depth used in the AI's algorithm

#endif