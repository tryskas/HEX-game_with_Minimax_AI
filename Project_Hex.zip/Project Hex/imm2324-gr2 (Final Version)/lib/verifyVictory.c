/**
* \file verifyVictory.c
* \brief Verify if there is a victory (or a tie) on the board
*
*
*/

// Includes all the headers and libraries needed
#include "header.h"

// Checks if the position of the move can be in the board
int isValidPosition (int x, int y)
{
    return (x >= 0 && x < SIZE && y >= 0 && y < SIZE);
}

// Checks the victory's condition
int sideConnected(int game_board[SIZE][SIZE], int x, int y, int player, int visited[6][6])
{ 
    // If the position of the move is invalid then return 0
    if (!isValidPosition(x, y))
    {
        return 0;
    }

    visited[x][y] = 1;

    if ((player == 1 && y == 5) || (player == 2 && x == 5))
    {
        return 1;
    }

    for (int yCoo = y-1; yCoo <= y+1; yCoo++)
    {
        for (int xCoo = x-1; xCoo <= x+1; xCoo++)
        {
            if (xCoo != x && yCoo != y)
            {
                if (game_board[xCoo][yCoo] == player && visited[xCoo][yCoo] == 0)
                {
                    if (sideConnected (game_board, xCoo, yCoo, player, visited) == 1)
                    {
                        return 1;
                    }
                }
            }
        }
    }
    return 0;
}

// Uses the principle of the depth search alorithm
int verifyVictory (int game_board[][SIZE], int player)
{
    int visited [SIZE][SIZE] = {{0}};

    if (player == 2)
    {
        for (int column = 0; column < SIZE; column++)
        {
            if ((game_board [0][column] == player) && (sideConnected(game_board, 0, column, player, visited) == 1))
            {
                return 1;
            }
        }
        return 0;
    }
    else
    {
        for (int column = 0; column < SIZE; column++)
        {
            if ((game_board [column][0] == player) && (sideConnected(game_board, column, 0, player, visited) == 1))
            {
                return 1;
            }
        }
        return 0;
    }
}