/**
* \file mainserv.c
* \brief Launch the game in server mode
*
*
*/

// Includes all the headers and libraries needed
#include <time.h>
#include <ctype.h>
#include "../reseau/server.c"
#include "../lib/header.h"
#include <limits.h>


char letter1[20] = "";
int end = 0;
int turn = 1;

int game_board[SIZE][SIZE];





int main(int argc, char *argv[]) {
    uint16_t PORTserver=atoi(argv[1]);


    game_board[SIZE][SIZE] = init(game_board);
    printing(game_board, turn);
    game_board[SIZE][SIZE] = init(game_board);
    int clientsocket = mainserv(PORTserver);
    char choixjoueur[20];
    printf("Choose your option (Player/AI) : ");
    scanf("%s", choixjoueur);


    // Main loop for the game
    while (end != 1)
    {
    // Test to know it it's a even or odd turn
    if(turn%2 == 0){
        // For an even turn (so it's the client's turn) :
        // If it's a player then we ask him for his move and print it if it's a possible move
        if(strcmp(choixjoueur, "Player") == 0){
            // Asking for the player's move
            printf("Which case do you want to color ? ");

            // The empty space before '%2s' is important
            // Allows the program not to loop (delete all the unwanted characters during prompt like /n)
            scanf(" %2s",&letter1[0]); 
            
            printf("MOVE TO PLAY : %s !!!!,%lu\n", &letter1[0], strlen(letter1));
            

            struct ResultValidity result = validity(letter1, game_board);
            
            // Tests for the validity of the move : if it is then we edit the board game and send the data
            if(result.valid){
                game_board[SIZE][SIZE] = editgame_board(game_board, result.column, result.line, turn);
                turn++;

                // Sends the data to the client
                char msg_to_send[3];
                sprintf(msg_to_send, "%d%d", result.column, result.line);
                printf("We send : message = %s column = %d line = %d \n", msg_to_send, result.column, result.line);
                
                send_data_to_client(clientsocket, msg_to_send);

            }else {
                // If the move is not valid then we warn the player and the loop restart until a move is possible
                printf("\nMove invalid...\n\n\n");
                
            }
            
        // If it's an AI then we it's making his move and sending it to the client
        }else{
            // The AI makes its move by using the alpha-beta algorithm
            SearchResult result = alphabeta(game_board, DEPTH_MAX, 2, INT_MIN, INT_MAX, 2);
            editgame_board (game_board, result.move.column, result.move.line, turn);
            turn++;

            // Prints the move made by the AI
            printf("The AI played the move : (%d, %d).\n", result.move.line, result.move.column);

            // Sends the message to the client
            char msg_to_send[3];
            sprintf(msg_to_send, "%d%d", result.move.column, result.move.line);

            send_data_to_client(clientsocket, msg_to_send);
        }
    }else{
        // For an odd turn (so it's the client's turn):
        
        // Receives the move of the client
        char msg_received[BUFFER_SIZE] = "";

        // Waiting for a message (not NULL) to arrive (refresh every 2 seconds)
        handle_client((int)(clientsocket), msg_received);
        sleep(2);
        
        

        // Updates the board game with the data received from the client
        struct ResultValidity result;
        result.column = msg_received[0];
        result.line = msg_received[1];
        game_board [SIZE][SIZE] = editgame_board(game_board, result.column-'0', result.line-'0', turn);
        turn++;
    }  

    // Prints the game board
    printing(game_board,turn);

    // Checks if there is a  tie or a winner, loops again the main loop if not
    if (turn == 37)
    {
        printf ("\t--------------------------------------------\n\t\t  It's a tie... too bad...\n\t--------------------------------------------\n\n\n");
        end++;
        close(clientsocket);
        return 0;
    }

    if (verifyVictory(game_board, (turn%2)+1) == 1)
    {
        printf ("\t--------------------------------------------\n\t  The player %d WON !!!\n\t--------------------------------------------\n\n\n", turn%2 + 1);
        end++;
        close(clientsocket);
        return 0;
    }
    else
    {
        printf ("\t--------------------------------------------\n\t  The player %d didn't won... for now...\n\t--------------------------------------------\n\n\n", turn%2 + 1);
    }
    }
}
