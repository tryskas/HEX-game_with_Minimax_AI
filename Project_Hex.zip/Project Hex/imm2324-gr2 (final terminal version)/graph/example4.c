#include <gtk/gtk.h>
#define SIZE 6



static void print_hello(GtkWidget *widget, gpointer data) {
    g_print("Hello World\n");
}

static void activate(GtkApplication *app, gpointer user_data) {
    GtkWidget *window;
    GtkWidget *grid;

    /* Crée une nouvelle fenêtre, et définit son titre */
    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "HEX");

    /* Ici, nous construisons le conteneur qui va emballer nos boutons */
    grid = gtk_grid_new();

    /* Emballer le conteneur dans la fenêtre */
     gtk_window_set_child(GTK_WINDOW(window), grid);

    GtkWidget* b;

    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
		char idx[11] = {col+65,row+1};
                b = gtk_button_new_with_label(idx);
                g_signal_connect(b, "clicked", G_CALLBACK(print_hello), NULL);

                /* Placez le premier bouton dans la cellule de la grille (0, 0) et faites-le remplir * seulement 1 cellule horizontalement et verticalement (c'est-à-dire pas de chevauchement) */
                gtk_grid_attach(GTK_GRID(grid), b, col, row, 1, 1);
}
}
gtk_widget_show(GTK_WIDGET(window));
}

int main(int argc, char **argv) {
    GtkApplication *app;
    int status;
    
    
    app = gtk_application_new("org.gtk.example", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
    status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    
    

    return status;
}
