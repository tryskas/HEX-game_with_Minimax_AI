def fill(i,j): # i lignes, j colonnes
  ret_text = ""
  for ligne in range(i):
    for  col in range(j):
      ret_text = ret_text + f"""
<child>
  <object id="{chr(97+col)}{ligne}" class="GtkButton">
    <property name="visible">True</property>
    <property name="label">{chr(97+col)},{ligne}</property>
  </object>
  <packing>
    <property name="left-attach">{ligne}</property>
    <property name="top-attach">{col}</property>
  </packing>
</child>
"""

  return ret_text

print(fill(6,6))
