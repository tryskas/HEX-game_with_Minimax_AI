+-------------------------------------------------
| Compilation
+-------------------------------------------------

At the root core of the program
Compilation, creates the executable ./prog
$ make
Documentations : production of the documents under ./docs
$ make docs

+-------------------------------------------------
| Using
+-------------------------------------------------

$ ./prog options