/**
* \file edit_board.c
* \brief Edit the array used for the game board
*
*
*/

// Includes all the headers and libraries needed
#include "header.h"
#include  <string.h>

int editgame_board(int game_board[][SIZE], int letter1, int letter2, int turn) {
    int val =0;
    if (turn%2 == 0){
        val=2;
    }else{
        val=1;
    }
    game_board[letter2][letter1] = val;
    return game_board[SIZE][SIZE];
}

struct ResultValidity validity(const char prompt[], int game_board[][SIZE]) {
    struct ResultValidity result;
    result.valid = 0;

    char *alphabetgame_board = "ABCDEF";
    char *little_alphabet_game_board = "abcdef";
    char *number_game_board = "123456";

    char letter1_prompt = (char)(prompt[0]);
    char letter2_prompt = (char)(prompt[1]);

    char *test_upper_letter = strchr(alphabetgame_board, letter1_prompt);
    char *test_lesser_letter = strchr(little_alphabet_game_board, letter1_prompt);
    char *test_number = strchr(number_game_board, letter2_prompt);

    int lenght_prompt = strlen(prompt);


    if ((test_upper_letter != NULL||test_lesser_letter != NULL) && (lenght_prompt == 2)) { // Test to verify if the prompt contains a letter and is of length 2
        if (test_number != NULL) { // Test to verify if the prompt contains a number
            
            if (test_lesser_letter != NULL) { // If it's a lesser letter
                int indexletter1 = letter1_prompt - 'a';
                int indexletter2 = *test_number -'1';
                int square_game_board = game_board[indexletter2][indexletter1];
                if (square_game_board == 0) {
                    // The square is empty so we can edit it
                    result.valid = 1;
                    result.column = indexletter1;
                    result.line = indexletter2;
                }
            } else { // If it's an upper letter
                int indexletter1 = letter1_prompt - 'A';
                int indexletter2 = *test_number -'1';
                int square_game_board = game_board[indexletter2][indexletter1];
                if (square_game_board == 0) {
                    // The square is empty so we can edit it
                    result.valid = 1;
                    result.column = indexletter1;
                    result.line = indexletter2;
                }
            }
        }
    }
    return result;
}