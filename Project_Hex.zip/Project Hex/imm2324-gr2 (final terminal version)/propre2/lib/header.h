/**
* \file header.h
* \brief Declares function and structures of all the files of the program
*
*
*/

#ifndef GAME_H
#define GAME_H

#define SIZE 6

#define BUFFER_SIZE 1024

#define DEPTH_MAX 5


/**
* \struct Move header.h alphaBeta.c
* \brief Structure to store the line and column of a move
*/
typedef struct
{
    /*! line of the corresponding move on the board*/
    int line;
    /*! column of the corresponding move on the board*/
    int column;
}Move;



/**
* \struct SearchResult header.h alphaBeta.c
* \brief Structure to store the value of the function SearchResult
*/
typedef struct
{
    /*! Score of a square if the AI made its move here */
    int value;
    /*! Uses the Move structure to save the coordinates of the move */
    Move move;
} SearchResult;


/**
* \struct ResultValidity header.h ediTab.c
* \brief Structure to store the result of the validity test
*/
struct ResultValidity {
    /*! Result of the validity test : 1 if the square is empty / 0 otherwise */
    int valid;
    /*! column of the corresponding move on the board*/
    int column;
    /*! line of the corresponding move on the board*/
    int line;
};


/**
* \fn init()
* \brief Constructor of the game_board
* \return Returns an empty array in 2D which size is defined by the const "SIZE" 
*/
int init();

/**
 * \fn validity(const char prompt[], int game_board[][SIZE])
 * \brief Check the validity of a move on the game board.
 * \param prompt The prompt message for input.
 * \param game_board The game board in 2D of 6 squares by 6 squares.
 * \return ResultValidity structure containing validity information.
 */
struct ResultValidity validity(const char prompt[], int game_board[][SIZE]);

/**
* \fn printing(int game_board[SIZE][SIZE], int turn)
* \brief Print in the terminal the edited game_board
* \param game_board The game_board in 2D of 6 squares by 6 squares
* \param turn The number of the actual turn
*/
void printing(int game_board[SIZE][SIZE], int turn);


/**
 * \fn editgame_board(int game_board[][SIZE], int index_letter1, int index_letter2, int turn)
 * \brief Edit the game board based on player moves.
 * \param game_board The game board in 2D of 6 squares by 6 squares.
 * \param index_letter1 The index of the first letter in the move.
 * \param index_letter2 The index of the second letter in the move.
 * \param turn The current turn number.
 * \return 1 if the move is valid, 0 if it is not.
 */
int editgame_board(int game_board[][SIZE], int index_letter1, int index_letter2, int turn);


/**
 * \fn isValidPosition(int x, int y)
 * \brief Check if a given position (x, y) is valid on the game board.
 * \param x The x-coordinate.
 * \param y The y-coordinate.
 * \return 1 if the position is valid, 0 if it is not.
 */
int isValidPosition(int x, int y);


/**
 * \fn verifyVictory(int game_board[][SIZE], int player)
 * \brief Check if a player has won the game.
 * \param game_board The game board in 2D of 6 squares by 6 squares.
 * \param player The player (1 or 2) to check for victory.
 * \return 1 if the player has won, 0 if not.
 */
int verifyVictory(int game_board[][SIZE], int player);


/**
 * \fn evaluate(int game_board[][SIZE], int player, int isServeur)
 * \brief Evaluate the current game state for a player.
 * \param game_board The game board in 2D of 6 squares by 6 squares.
 * \param player The player (1 or 2) for whom the evaluation is done.
 * \param isServeur Flag indicating if the player is a server.
 * \return The evaluation score for the player.
 */
int evaluate(int game_board[][SIZE], int player, int isServeur);


/**
 * \fn alphabeta(int game_board[][SIZE], int depth, int joueur, int alpha, int beta, int isServeur)
 * \brief Perform alpha-beta pruning for game tree traversal.
 * \param game_board The game board in 2D of 6 squares by 6 squares.
 * \param depth The current depth of the search.
 * \param joueur The current player (1 or 2).
 * \param alpha The alpha value for alpha-beta pruning.
 * \param beta The beta value for alpha-beta pruning.
 * \param isServeur Flag indicating if the player is a server.
 * \return The SearchResult structure containing the best move and its value.
 */
SearchResult alphabeta(int game_board[][SIZE], int depth, int joueur, int alpha, int beta, int isServeur);


/**
 * \fn countMobility
 * \brief Count the number of available moves for a player.
 * \param game_board The game board in 2D of 6 squares by 6 squares.
 * \param player The player (1 or 2) for whom the mobility is counted.
 * \return The number of available moves for the player.
 */
int countMobility(int game_board[][SIZE], int player);

#endif