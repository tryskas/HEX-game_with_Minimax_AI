/**
* \file init_board.c
* \brief Return an empty array of 6 squares by 6 squares 
*
*
*/

// Includes all the headers and libraries needed
#include "header.h"
#include <stdio.h>


//Avoids with #endif at the end of the file to get multiple inclusions
#ifndef INIT
#define INIT

int init(int game_board[SIZE][SIZE]){
// Initialising the game board via an array
    int line,column=0;
    for(line=0; line<SIZE; ++line){
        for(column=0; column<SIZE; ++column){
            game_board[line][column]=0;
        }
    }
    return game_board[SIZE][SIZE];
}

#endif