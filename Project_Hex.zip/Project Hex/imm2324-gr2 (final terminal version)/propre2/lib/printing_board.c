/**
* \file printing_board.c
* \brief Prints the array used for the game_board in the terminal
*
*
*/

// Includes all the headers and libraries needed
#include "header.h"
#include <stdio.h>

void printing(int tableau[SIZE][SIZE], int tour){
    
    int i,j=0;
    printf("IT'S THE TURN NUMBER %d\n--------------------\n", tour);
    printf ("\n  | A B C D E F |");
    printf ("\n--|-------------|-\n");

    int count =1;
    for(i=0; i<SIZE; ++i){
        printf ("%d | ", count);
        for(j=0; j<SIZE; ++j){
            if (tableau[i][j] == 1)
            {
                printf("\033[1;34m%d\033[0m  ",tableau[i][j]);
            }
            else if (tableau[i][j] == 2)
            {
                printf("\033[1;31m%d\033[0m ", tableau[i][j]);
            }
            else
            {
                printf("%d ",tableau[i][j]);
            }
        }
        count ++;
        printf("|\n");
    }
    printf ("--|-------------|-\n");
}