/**
* \file main.c
* \brief Launch the game in server/client (-s/-c) & Player/AI mode depending on the parameters by redirecting to the corresponding files
*
*
*/

// Includes all the headers and libraries needed
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
 
int main(int argc, char *argv[]) 
{

    if (argc == 3)
    {
        if (strcmp(argv[1],"-c") == 0)
        {
            if(argv[2]){
                char *cut=strtok(argv[2],":");
                char *IP=cut;
                cut = strtok(NULL, ":"); //passer au suivant
                if (cut){
                char *PORT=cut;
                printf("IP = %s PORT = %s",IP,PORT);
                printf("Launching mainclient.c...\n");

                char commande[100];
                sprintf(commande,"./mainclient.exe %s %s",IP,PORT);
                printf("%s",commande);
                system(commande); // Execute mainclient
                }else{
                    printf("missing one argument\n");
                }                
            }else{
                printf("no second argument given\n");
            }
            

        }
        else if (strcmp(argv[1],"-s") == 0)
        {
            if(argv[2]){
                printf("PORT =%s\n",argv[2]);
                char commande[100];
                sprintf(commande,"./mainserv.exe %s",argv[2]);
                printf("%s",commande);

                printf ("My computer is in server mode\n");
                printf("Launching mainserv.c...\n");
                system(commande); // Execute mainserv
            }else{
                printf("No second argument given\n");
            }
            
            
        }
        else if (strcmp(argv[1],"-l") == 0)
        {  
            printf ("My computer is in local mode\n");
            if(argv[2]){
                if(strcmp(argv[2],"bleu")==0){
                    system("./mainclient.exe 1235"); // Exécuter mainserv
                }else if(strcmp(argv[2],"rouge")==0){
                    system("./mainserv.exe 127.0.0.0:1235"); // Exécuter mainserv
                }else{
                    printf("unavalable argument given\n");
                }
                
            }else{
                printf("no second argument given\n");
            }
            
            


        }
        else
        {
            printf ("wrong OPTION");
        }

        return 0;
    }
    else
    {
        printf ("\nwrong expression : use the following sentence to execute the program :");
        printf ("\n\t\t./hex [OPTION : -l for local] [OPTION : RED or BLUE]");
        printf ("\n\t\t./hex [OPTION : -s for server] [NUMBER of the ]");
        printf ("\n\t\t./hex [OPTION : -c for client] [IP.IP.IP.IP:Num_Port]\n");

        return 0;
    }

}