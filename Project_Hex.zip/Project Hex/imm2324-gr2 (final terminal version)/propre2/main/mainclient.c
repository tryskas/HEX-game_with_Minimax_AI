/**
* \file mainclient.c
* \brief Launch the game in client mode
*
*
*/

// Includes all the headers and libraries needed
#include "../lib/header.h"
#include "../reseau/client.c"
#include <limits.h>


char letter1[20] = "";
int end = 0;
int turn = 1;

int game_board[SIZE][SIZE];

void main(int argc, char *argv[]) {
    char *IPClient =argv[1];
    char *PORTclient=argv[2];
    printf("IP = %s PORT=%s \n",IPClient);//IPClient,

    game_board[SIZE][SIZE] = init(game_board);
    printing(game_board,turn);
    int PORTT=atoi(PORTclient);
    printf("PORTT %d \n",PORTT);
    int clientsocket = mainclient(IPClient,PORTT);//IPClient,PORTclient
    char choixjoueur[20];
    printf("Choose your option (Player/AI) : ");
    scanf("%s",choixjoueur);

    
    // Main loop for the game
    while (end != 1)
    {
    printf("Turn = %d \n",turn%2 != 0);
    // Test to know it it's a even or odd turn
    if(turn%2 != 0){
        // For an odd turn (so it's the client's turn) :
        // If it's a player then we ask him for his move and print it if it's a possible move
        if(strcmp(choixjoueur, "Player") == 0){
            // Asking for the player's move
            printf("Which case do you want to color ? ");

            // The empty space before '%2s' is important
            // Allows the program not to loop (delete all the unwanted characters during prompt like /n)
            scanf(" %2s", &letter1[0]);
            
            printf("MOVE TO PLAY : %s !!!!\n", &letter1[0]);
            
            
            struct ResultValidity result = validity(letter1, game_board);
            
            // Tests for the validity of the move : if it is then we edit the board game and send the data
            if(result.valid){
                game_board[SIZE][SIZE] = editgame_board(game_board, result.column, result.line,turn);
                turn++;

                // Sends the data to the server
                char msg_to_send[3];
                sprintf(msg_to_send, "%d%d", result.column, result.line);
                printf("We send : message = %s column = %d line = %d \n", msg_to_send, result.column, result.line);
                
                send_data_to_server(clientsocket, msg_to_send);

            }else {
                // If the move is not valid then we warn the player and the loop restart until a move is possible
                printf("\nMove invalid...\n\n\n");
                
            }

        // If it's an AI then we it's making his move and sending it to the client
        }else{
           // The AI makes its move by using the alpha-beta algorithm
            SearchResult result = alphabeta(game_board, DEPTH_MAX, 1, INT_MIN, INT_MAX, 1);
            editgame_board (game_board, result.move.column, result.move.line, turn);           
            turn++;

            // Prints the move made by the AI
            printf("The AI played the move : (%d, %d).\n", result.move.line, result.move.column);

            // Sends the message to the server
            char msg_to_send[3];
            sprintf(msg_to_send, "%d%d", result.move.column, result.move.line);
            printf("We send : message = %s column = %d line = %d \n", msg_to_send, result.move.column, result.move.line);

            send_data_to_server(clientsocket, msg_to_send);
        }
    }else{
        // For an even turn (so it's the server's turn):
        
        // Receives the move of the server
        char msg_received[BUFFER_SIZE] = "";
        printf("MESSAGE RECEIVED %s %lu \n", msg_received, strlen(msg_received));

        // Waiting for a message (not NULL) to arrive (refresh every 2 seconds)
        handle_server((int)(clientsocket), msg_received);
        sleep(2);
        
        printf("Reception of : %s\n", (msg_received));

        // Updates the board game with the data received from the client
        struct ResultValidity result;
        result.column = msg_received[0];
        result.line = msg_received[1];
        printf("Move at : %d %d\n", result.column, result.line);  
        game_board[SIZE][SIZE] = editgame_board(game_board, result.column-'0', result.line-'0', turn);
        turn++;            
    }

    // Prints the game board
    printing(game_board,turn);

    // Checks if there is a winner or a tie, loops again the main if not 
    if (verifyVictory(game_board, (turn%2)+1) == 1)
    {
        printf ("\n\t\tThe player %d WON !!!\n", turn%2 + 1);
        end++;
    }
    else if (verifyVictory(game_board, (turn%2)+1) == 2)
    {
        printf ("\n\t\tIt's a tie... too bad...");
        end++;
    }
    else
    {
        printf ("\n\t\tThe player %d didn't won... for now...\n", turn%2 + 1);
    }
    
    }
}



