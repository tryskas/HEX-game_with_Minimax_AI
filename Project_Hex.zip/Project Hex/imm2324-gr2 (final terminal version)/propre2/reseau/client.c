/**
* \file server.c
* \brief Creates the client parameters for the server to use
*
*
*/


//Avoids with #endif at the end of the file to get multiple inclusions
#ifndef CLIENT
#define CLIENT
//#define SERVER_IP "10.39.251.197"
//#define PORT 1234
// Includes all the headers and libraries needed
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "../lib/const.h"

void cleanstring(char *str) {
    size_t len = strlen(str);

    // Parcourez la chaîne de caractères à partir de la fin
    while (len > 0 && (str[len - 1] == '\n' || str[len - 1] == '\r')) {
        str[len - 1] = '\0'; // Remplacez les caractères de fin de ligne par le caractère nul
        len--;
    }
}
 
// Function to send the data to the server
void send_data_to_server(int client_socket, const char* data) {
    ssize_t bytes_sent;
 
    // Sends the data to the server
    bytes_sent = send(client_socket, data, strlen(data), 0);
    if (bytes_sent < 0) {
        perror("Error while sending the data to server");
        close(client_socket);
        exit(EXIT_FAILURE);
    }
}
 
// Function to get data from server
void handle_server(int client_socket,char* buffer) {
    ssize_t bytes_received;
 
    // Waits for data from the server
    bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
    if (bytes_received < 0) {
        //perror("Error while receiving the message from server");
        return;
    }
 

	// Prints the message from the server
	printf("Message of server : %s\n", buffer);
	
}
 
int mainclient(const char *SERVER_IP,int PORT) {//const char *SERVER_IP,
    int client_socket;
    struct sockaddr_in server_addr;

    // Create a client socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("Error while creating the socket client");
        exit(EXIT_FAILURE);
    }

    // Configure the server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);
    server_addr.sin_port = htons(PORT);
    printf("TEST %d %d \n",server_addr.sin_addr.s_addr ,server_addr.sin_port);
    // Connect to the server
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error while connecting to the server");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    // Connection successful, return the client socket
    return client_socket;
}

#endif