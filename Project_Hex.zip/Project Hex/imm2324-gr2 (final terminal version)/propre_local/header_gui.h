#ifndef HEADER_GUI_H
#define HEADER_GUI_H

#include "globals_gui.h"

typedef struct
{
    int line;
    int column;
}Move;


typedef struct
{
    int value;
    Move move;
} SearchResult;


// Structure to store the result of the validity test
struct ResultatValable {
    int valid;
    int column;
    int line;
};



int countMobility(int game_board[][SIZE], int player);
int calculateAverageDistanceToEdges(int game_board[][SIZE], int player);
int evaluate (int game_board[][SIZE], int player, int isClient);
SearchResult alphabeta( int game_board[][SIZE],int depth, int player, int alpha, int beta, int isClient);
void valable_struct(struct ResultatValable* action, int tableau[][SIZE]);
int map_1d_to_row(int idx);
int map_1d_to_row(int idx);
int get_pos_widget_in_array(GtkWidget *widget, GtkWidget **grid, int grid_size);
int map_2d_to_1d(int row, int col);
void int2Char(int d, char buffer[3]);
void update_turn_label();
static void print_hello(GtkWidget *widget, gpointer data);
static void quit_application(GtkWidget *widget, gpointer gp_app);
static void open_window_local_jcj(GtkWidget *widget, gpointer data);
static void open_window_local_ia(GtkWidget *widget, gpointer data);
static void open_window_special_ia(GtkWidget *widget, gpointer data);
static void callback_entry_p2(GtkWidget *bouton_entry_p2, gpointer user_data);
static void callback_entry_p1(GtkWidget *bouton_entry_p1, gpointer user_data);
static void update_gui_turn(GtkWidget *widget, gpointer p_tour);
int editgame_board(int index_letter1, int index_letter2, int turn);
int controleur_jeu(struct ResultatValable* prompt);
static void wrapper_for_callback(GtkWidget* widget, gpointer data);
int sideConnected(int tab[SIZE][SIZE], int x, int y, int player, int visited [6][6]);
int isValidPosition (int x, int y);
int verifyVictory (int tab[][SIZE], int player);





#endif